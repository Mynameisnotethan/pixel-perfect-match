#!/bin/bash

STATUS_TITLE() {
	echo -ne "\033[0;34m${1}: \033[0m"
}

STATUS_DONE() {
	echo -e "\033[0;33mDone √\033[0m"
}

STATUS_ERROR() {
	echo -e "\033[1;31mError ×\033[0m"
}

# Configure Cypht
setup_cypht() {
    cp .github/tests/.env .
    if [ "$DB" = "postgres" ]; then
        # .env
        sed -i 's/DB_DRIVER=mysql/DB_DRIVER=pgsql/' .env
        # mocks.php
        sed -i 's/mysql/pgsql/' tests/phpunit/mocks.php
    fi
    if [ "$DB" = "sqlite" ]; then
        # .env
        sed -i 's/DB_DRIVER=mysql/DB_DRIVER=sqlite/' .env
        sed -i 's|DB_NAME=.*|DB_NAME=/tmp/test.db|' .env
        # mocks.php
        sed -i 's/mysql/sqlite/' tests/phpunit/mocks.php
        sed -i "s/'host'/'socket'/" tests/phpunit/mocks.php
    fi

    sed -i "s|ATTACHMENT_DIR=.*|ATTACHMENT_DIR=$(pwd)/hm3/attachments|" .env
    php scripts/config_gen.php
}

# Create and populate database for phpunit tests
setup_db() {
    echo "SETTING UP DB $DB"
    if [ "$DB" = "postgres" ]; then
        PGPASSWORD=cypht_test psql -h 127.0.0.1 -U cypht_test -d cypht_test -c 'CREATE TABLE hm_user (username varchar(255) primary key not null, hash varchar(255));'
        PGPASSWORD=cypht_test psql -h 127.0.0.1 -U cypht_test -d cypht_test -c 'CREATE TABLE hm_user_session (hm_id varchar(250) primary key not null, data text, date timestamp);'
        PGPASSWORD=cypht_test psql -h 127.0.0.1 -U cypht_test -d cypht_test -c 'CREATE TABLE hm_user_settings (username varchar(250) primary key not null, settings text);'
        PGPASSWORD=cypht_test psql -h 127.0.0.1 -U cypht_test -d cypht_test -c "insert into hm_user values('unittestuser', 'sha512:86000:xfEgf7NIUQ2XkeU5tnIcA+HsN8pUllMVdzpJxCSwmbsZAE8Hze3Zs+MeIqepwocYteJ92vhq7pjOfrVThg/p1voELkDdPenU8i2PgG9UTI0IJTGhMN7rsUILgT6XlMAKLp/u2OD13sukUFcQNTdZNFqMsuTVTYw/Me2tAnFwgO4=:rfyUhYsWBCknx6EmbeswN0fy0hAC0N3puXzwWyDRquA=');"
        PGPASSWORD=cypht_test psql -h 127.0.0.1 -U cypht_test -d cypht_test -c "insert into hm_user values('testuser', '\$argon2id\$v=19\$m=65536,t=2,p=1\$dw4pTU24zRKHCEkLcloU/A\$9NJm6ALQhVpB2HTHmVHjOai912VhURUDAPsut5lrEa0');"
        PGPASSWORD=cypht_test psql -h 127.0.0.1 -U cypht_test -d cypht_test -c "insert into hm_user_settings values('testuser', 'sFpVPU/hPvmfeiEKUBs4w1EizmbW/Ze2BALZf6kdJrIU3KVZrsqIhKaWTNNFRm3p51ssRAH2mpbxBMhsdpOAqIZMXFHjLttRu9t5WZWOkN7qwEh2LRq6imbkMkfqXg//K294QDLyWjE0Lsc/HSGqnguBF0YUVLVmWmdeqq7/OrXUo4HNbU88i4s2gkukKobJA2hjcOEq/rLOXr3t4LnLlcISnUbt4ptalSbeRrOnx4ehZV8hweQf1E+ID7s/a+8HHx1Qo713JDzReoLEKUsxRQ==');"
    fi
    if [ "$DB" = "mysql" ]; then
        mysql --defaults-extra-file=.github/tests/my.cnf -e 'create table hm_user (username varchar(255), hash varchar(255), primary key (username));' cypht_test
        mysql --defaults-extra-file=.github/tests/my.cnf -e 'create table hm_user_session (hm_id varchar(255), data longblob, date timestamp, primary key (hm_id));' cypht_test
        mysql --defaults-extra-file=.github/tests/my.cnf -e 'create table hm_user_settings(username varchar(255), settings longblob, primary key (username));' cypht_test
        mysql --defaults-extra-file=.github/tests/my.cnf -e "insert into hm_user values('unittestuser', 'sha512:86000:xfEgf7NIUQ2XkeU5tnIcA+HsN8pUllMVdzpJxCSwmbsZAE8Hze3Zs+MeIqepwocYteJ92vhq7pjOfrVThg/p1voELkDdPenU8i2PgG9UTI0IJTGhMN7rsUILgT6XlMAKLp/u2OD13sukUFcQNTdZNFqMsuTVTYw/Me2tAnFwgO4=:rfyUhYsWBCknx6EmbeswN0fy0hAC0N3puXzwWyDRquA=');" cypht_test
        mysql --defaults-extra-file=.github/tests/my.cnf -e "insert into hm_user values('testuser', '\$argon2id\$v=19\$m=65536,t=2,p=1\$dw4pTU24zRKHCEkLcloU/A\$9NJm6ALQhVpB2HTHmVHjOai912VhURUDAPsut5lrEa0');" cypht_test
        mysql --defaults-extra-file=.github/tests/my.cnf -e "insert into hm_user_settings values('testuser', 'sFpVPU/hPvmfeiEKUBs4w1EizmbW/Ze2BALZf6kdJrIU3KVZrsqIhKaWTNNFRm3p51ssRAH2mpbxBMhsdpOAqIZMXFHjLttRu9t5WZWOkN7qwEh2LRq6imbkMkfqXg//K294QDLyWjE0Lsc/HSGqnguBF0YUVLVmWmdeqq7/OrXUo4HNbU88i4s2gkukKobJA2hjcOEq/rLOXr3t4LnLlcISnUbt4ptalSbeRrOnx4ehZV8hweQf1E+ID7s/a+8HHx1Qo713JDzReoLEKUsxRQ==');" cypht_test
    fi
    if [ "$DB" = "sqlite" ]; then
        touch /tmp/test.db
        chmod 666 /tmp/test.db
        sqlite3 /tmp/test.db 'create table hm_user (username varchar(255), hash varchar(255), primary key (username));'
        sqlite3 /tmp/test.db 'create table hm_user_session (hm_id varchar(255), data longblob, date timestamp, primary key (hm_id));'
        sqlite3 /tmp/test.db 'create table hm_user_settings(username varchar(255), settings longblob, primary key (username));'
        sqlite3 /tmp/test.db "insert into hm_user values('unittestuser', 'sha512:86000:xfEgf7NIUQ2XkeU5tnIcA+HsN8pUllMVdzpJxCSwmbsZAE8Hze3Zs+MeIqepwocYteJ92vhq7pjOfrVThg/p1voELkDdPenU8i2PgG9UTI0IJTGhMN7rsUILgT6XlMAKLp/u2OD13sukUFcQNTdZNFqMsuTVTYw/Me2tAnFwgO4=:rfyUhYsWBCknx6EmbeswN0fy0hAC0N3puXzwWyDRquA=');"
        sqlite3 /tmp/test.db "insert into hm_user values('testuser', '\$argon2id\$v=19\$m=65536,t=2,p=1\$dw4pTU24zRKHCEkLcloU/A\$9NJm6ALQhVpB2HTHmVHjOai912VhURUDAPsut5lrEa0');"
        sqlite3 /tmp/test.db "insert into hm_user_settings values('testuser', 'sFpVPU/hPvmfeiEKUBs4w1EizmbW/Ze2BALZf6kdJrIU3KVZrsqIhKaWTNNFRm3p51ssRAH2mpbxBMhsdpOAqIZMXFHjLttRu9t5WZWOkN7qwEh2LRq6imbkMkfqXg//K294QDLyWjE0Lsc/HSGqnguBF0YUVLVmWmdeqq7/OrXUo4HNbU88i4s2gkukKobJA2hjcOEq/rLOXr3t4LnLlcISnUbt4ptalSbeRrOnx4ehZV8hweQf1E+ID7s/a+8HHx1Qo713JDzReoLEKUsxRQ==');"
    fi
}

# Setup base data needed by the phpunit tests
bootstrap_unit_tests() {
    setup_db
    echo '+2IdQejfHu4FNYOA3tm0DJVQNg92gcpJf8ETeVj+HK0OU6J5iaV/J823rLm8+5Et7tQLoCCoZwElGTH7N2P2M4JMct1jRyWgjqJQn9FYlovFYj/8fLwkixGo+VMNIKsUwJ42GXTj61nn0Rf4+FO688SfAR5LhaLTXlR6XZ9mJD2/2RX1X+Z1JVl7SrqELgE8wnz5IYCrzqBbgK4MDn86rTtPM9jie3gFS9viMZ7OQRENbXLvwBaIXNLvQlZZn2JBdzXF1spoLnSlq8P0pYXlDig==' > tests/phpunit/data/testuser.txt
}

# output some system info
sys_info() {
    df -h
    sudo netstat -lntp
}

##### UI START #####
# Add a system user dovecot will use for authentication
setup_user() {
	STATUS_TITLE "Setup MailUser"
	sudo useradd -m -p '$1$BMvnSsOY$DXbm292ZTfTwuEwUpu/Lo/' testuser
	sudo mkdir -p /home/testuser/mail/.imap/INBOX
	sudo chown -R testuser:testuser /home/testuser
    sudo chmod 700 /home/testuser/mail/.imap
	sudo usermod -aG mail testuser
	sudo usermod -aG postdrop testuser

    sudo systemctl restart dovecot

	STATUS_DONE
}
# test dovecot user authentication
test_user_setup() {
    STATUS_TITLE "Test MailUser After Setup"

    # Test authentication with doveadm
    echo "Testing Dovecot authentication for 'testuser@localhost'..."
    sudo doveadm auth test testuser testuser

    # Try SMTP login manually via STARTTLS
    echo -e "EHLO localhost\r\nAUTH PLAIN $(printf '\0testuser@localhost\0testuser' | base64)\r\nQUIT\r\n" | \
      openssl s_client -connect localhost:25 -starttls smtp -crlf

    # Try IMAP login manually (plaintext)
    echo -e "a login testuser@localhost testuser\r\na logout\r\n" | \
      openssl s_client -connect localhost:143 -crlf

    # Check if Postfix auth socket exists
    echo "Checking Postfix auth socket..."
    sudo ls -l /var/spool/postfix/private/auth
    sudo test -S /var/spool/postfix/private/auth && echo "Socket exists"

    STATUS_DONE
}

# config Dovecot
setup_dovecot() {
	STATUS_TITLE "Setup Dovecot"
	sudo bash .github/tests/scripts/dovecot.sh
	if [ "$(sudo systemctl is-active dovecot.service)" == "active" ]; then
		STATUS_DONE
	else
		STATUS_ERROR
		exit 1
	fi
}

# config postfix
setup_postfix() {
	STATUS_TITLE "Setup Postfix"
	sudo bash .github/tests/scripts/postfix.sh
	if [ "$(sudo systemctl is-active postfix.service)" == "active" ]; then
		STATUS_DONE
	else
		STATUS_ERROR
		exit 1
	fi
}

# setup OpenLDAP test data
setup_ldap() {
	STATUS_TITLE "Setup OpenLDAP"
	bash .github/tests/scripts/ldap.sh
	if [ $? -eq 0 ]; then
		STATUS_DONE
	else
		STATUS_ERROR
		echo "Warning: LDAP setup failed - LDAP tests may be skipped"
	fi
}

# The GitHub runner image can leave a regular file at phpX.Y-fpm.sock.
# php-fpm will not replace it, and nginx then returns 502 with
# "connect() to unix:/run/php/phpX.Y-fpm.sock failed (13: Permission denied)".
configure_fpm_pool() {
	local pool="/etc/php/${PHP_V}/fpm/pool.d/www.conf"
	local sock="/run/php/php${PHP_V}-fpm.sock"
	if [ ! -f "$pool" ]; then
		echo "FPM pool not found: $pool"
		return 1
	fi
	sudo sed -i -E "s|^[;[:space:]]*listen = .*|listen = ${sock}|" "$pool"
	sudo sed -i -E "s|^[;[:space:]]*listen\\.owner = .*|listen.owner = www-data|" "$pool"
	sudo sed -i -E "s|^[;[:space:]]*listen\\.group = .*|listen.group = www-data|" "$pool"
	sudo sed -i -E "s|^[;[:space:]]*listen\\.mode = .*|listen.mode = 0660|" "$pool"
	sudo grep -q '^listen = ' "$pool" || echo "listen = ${sock}" | sudo tee -a "$pool" >/dev/null
	sudo grep -q '^listen.owner = ' "$pool" || echo "listen.owner = www-data" | sudo tee -a "$pool" >/dev/null
	sudo grep -q '^listen.group = ' "$pool" || echo "listen.group = www-data" | sudo tee -a "$pool" >/dev/null
	sudo grep -q '^listen.mode = ' "$pool" || echo "listen.mode = 0660" | sudo tee -a "$pool" >/dev/null
}

#config site
setup_site() {
	STATUS_TITLE "Setup php${PHP_V}-fpm"
	sudo systemctl stop php"${PHP_V}"-fpm.service || true
	if ! configure_fpm_pool; then
		STATUS_ERROR
		exit 1
	fi
	sudo rm -f "/run/php/php${PHP_V}-fpm.sock"
	sudo systemctl start php"${PHP_V}"-fpm.service
	if [ "$(sudo systemctl is-active php"${PHP_V}"-fpm.service)" == "active" ] && sudo test -S "/run/php/php${PHP_V}-fpm.sock"; then
		STATUS_DONE
	else
		STATUS_ERROR
		exit 1
	fi
	
	STATUS_TITLE "Setup Nginx"
	sudo systemctl stop nginx.service
	
	grep -qxF "127.0.0.1 cypht-test.org" /etc/hosts || echo "127.0.0.1 cypht-test.org" | sudo tee -a /etc/hosts
	
	sudo cp .github/tests/selenium/nginx/nginx-site.conf /etc/nginx/sites-available/default
	sudo mkdir -p /etc/nginx/nginxconfig
	sudo cp .github/tests/selenium/nginx/php_fastcgi.conf /etc/nginx/nginxconfig/php_fastcgi.conf
	sudo sed -e "s?%VERSION%?${PHP_V}?g" --in-place /etc/nginx/sites-available/default

	# Copy files instead of symlink to avoid permission issues
	sudo rm -rf /var/www/cypht
	sudo cp -r "$(pwd)" /var/www/cypht
	
	sudo chown -R www-data:www-data /var/www/cypht
	sudo chmod -R 755 /var/www/cypht
	
	# Reconfigure Cypht for the new location
	cd /var/www/cypht
	sudo -u www-data cp .github/tests/.env .
	if [ "$DB" = "sqlite" ]; then
		sudo -u www-data sed -i 's/DB_DRIVER=mysql/DB_DRIVER=sqlite/' .env
		sudo -u www-data sed -i 's|DB_NAME=.*|DB_NAME=/tmp/test.db|' .env
	fi
	sudo -u www-data sed -i "s|ATTACHMENT_DIR=.*|ATTACHMENT_DIR=/var/www/cypht/hm3/attachments|" .env
	sudo -u www-data php scripts/config_gen.php
	cd - > /dev/null

	sudo nginx -t
	if [ $? -ne 0 ]; then
		STATUS_ERROR
		exit 1
	fi

	sudo systemctl start nginx.service

	CYPHT_STATUS=$(curl -s -o /dev/null -w '%{http_code}' 'http://cypht-test.org')
	LOCALHOST_STATUS=$(curl -s -o /dev/null -w '%{http_code}' 'http://localhost')
	
	if [ "$CYPHT_STATUS" -eq 200 ] || [ "$LOCALHOST_STATUS" -eq 200 ]; then
		STATUS_DONE
	else
		STATUS_ERROR
		exit 1
	fi
	
    STATUS_TITLE "Setup required Directories"
    sudo mkdir -p /var/www/cypht/hm3/attachments
    sudo mkdir -p /var/www/cypht/hm3/users
    sudo chown -R www-data:www-data /var/www/cypht/hm3
    sudo chmod -R 755 /var/www/cypht/hm3
	STATUS_DONE
}

##### UI END #####

# setup just what is needed for the phpunit unit tests
setup_unit_tests() {
    setup_cypht
    bootstrap_unit_tests
    setup_ldap
}

setup_ui_tests() {
    setup_cypht
    bootstrap_unit_tests
    setup_user
    setup_dovecot
    setup_postfix
    setup_ldap
    test_user_setup
    setup_site
}

# Main
echo "database: ${DB}"
echo "php-version: ${PHP_V}"
echo "test-arg: ${TEST_ARG}"

ARG="${TEST_ARG}"
case "$ARG" in
    phpunit)
        setup_unit_tests
    ;;
    selenium)
        setup_ui_tests
    ;;
    *)
        setup_unit_tests
    ;;
esac

sys_info
