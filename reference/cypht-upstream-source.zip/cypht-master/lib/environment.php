<?php

/**
 * Environment objects
 * @package framework
 * @subpackage environment
 */

class Hm_Environment {

    private static $instance;

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new static();
        }
        return self::$instance;
    }

    public function load($file = '.env') {
        $this->set_required_environment_variables($file);

        $dotenvLoader = new \Symfony\Component\Dotenv\Dotenv();
        if (method_exists($dotenvLoader, 'usePutenv')) {
            $dotenvLoader->usePutenv(true);
        }
        $envFile = static::get('CYPHT_DOTENV');
        if (!file_exists($envFile)) {
            Hm_Msgs::add('.env file not found at: "' . $envFile . '"', 'danger');
            return;
        }
        $dotenvLoader->load($envFile);
    }

    public static function get($key, $default = null) {
        $variables = self::getInstance()->get_environment_variables();
        return $variables[$key] ?? $default;
    }

    public function define_default_constants($config) {
        $this->define_constant('DEFAULT_SEARCH_SINCE', $config->get('default_setting_search_since', '-1 week'));
        $this->define_constant('DEFAULT_UNREAD_SINCE', $config->get('default_setting_unread_since', '-1 week'));
        $this->define_constant('DEFAULT_UNREAD_PER_SOURCE', $config->get('default_setting_unread_per_source', 20));
        $this->define_constant('DEFAULT_FLAGGED_SINCE', $config->get('default_setting_flagged_since', '-1 week'));
        $this->define_constant('DEFAULT_FLAGGED_PER_SOURCE', $config->get('default_setting_flagged_per_source', 20));
        $this->define_constant('DEFAULT_SEARCH_ALL_FOLDERS', $config->get('default_setting_search_all_folders', false));
        $this->define_constant('DEFAULT_ALL_SINCE', $config->get('default_setting_all_since', '-1 week'));
        $this->define_constant('DEFAULT_ALL_PER_SOURCE', $config->get('default_setting_all_per_source', 20));
        $this->define_constant('DEFAULT_ALL_EMAIL_SINCE', $config->get('default_setting_all_email_since', '-1 week'));
        $this->define_constant('DEFAULT_ALL_EMAIL_PER_SOURCE', $config->get('default_setting_all_email_per_source', 20));
        $this->define_constant('DEFAULT_FEED_SINCE', $config->get('default_setting_feed_since', '-1 week'));
        $this->define_constant('DEFAULT_FEED_LIMIT', $config->get('default_setting_feed_limit', 20));
        $this->define_constant('DEFAULT_SENT_SINCE', $config->get('default_setting_sent_since', '-1 week'));
        $this->define_constant('DEFAULT_SENT_PER_SOURCE', $config->get('default_setting_sent_per_source', 20));
        $this->define_constant('DEFAULT_UNREAD_EXCLUDE_FEEDS', $config->get('default_setting_unread_exclude_feeds', false));
        $this->define_constant('DEFAULT_LIST_STYLE', $config->get('default_setting_list_style', 'email_style'));
        $this->define_constant('DEFAULT_IMAP_PER_PAGE', $config->get('default_setting_imap_per_page', 20));
        $this->define_constant('DEFAULT_JUNK_SINCE', $config->get('default_setting_junk_since', '-1 week'));
        $this->define_constant('DEFAULT_JUNK_PER_SOURCE', $config->get('default_setting_junk_per_source', 20));
        $this->define_constant('DEFAULT_SNOOZED_SINCE', $config->get('default_setting_snoozed_since', '-1 week'));
        $this->define_constant('DEFAULT_SNOOZED_PER_SOURCE', $config->get('default_setting_snoozed_per_source', 20));
        $this->define_constant('DEFAULT_ENABLE_SNOOZE', $config->get('default_setting_enable_snooze', true));
        $this->define_constant('DEFAULT_TAGS_SINCE', $config->get('default_setting_tags_since', '-1 week'));
        $this->define_constant('DEFAULT_TAGS_PER_SOURCE', $config->get('default_setting_tags_per_source', 20));
        $this->define_constant('DEFAULT_TRASH_SINCE', $config->get('default_setting_trash_since', '-1 week'));
        $this->define_constant('DEFAULT_TRASH_PER_SOURCE', $config->get('default_setting_trash_per_source', 20));
        $this->define_constant('DEFAULT_DRAFT_SINCE', $config->get('default_setting_draft_since', '-1 week'));
        $this->define_constant('DEFAULT_DRAFT_PER_SOURCE', $config->get('default_setting_draft_per_source', 20));
        $this->define_constant('DEFAULT_SIMPLE_MSG_PARTS', $config->get('default_setting_simple_msg_parts', false));
        $this->define_constant('DEFAULT_MSG_PART_ICONS', $config->get('default_setting_msg_part_icons', true));
        $this->define_constant('DEFAULT_PAGINATION_LINKS', $config->get('default_setting_pagination_links', true));
        $this->define_constant('DEFAULT_REVIEW_SENT_EMAIL', $config->get('default_setting_review_sent_email', true));
        $this->define_constant('DEFAULT_TEXT_ONLY', $config->get('default_setting_text_only', false));
        $this->define_constant('DEFAULT_NO_PASSWORD_SAVE', $config->get('default_setting_no_password_save', false));
        $this->define_constant('DEFAULT_SHOW_LIST_ICONS', $config->get('default_setting_show_list_icons', true));
        $this->define_constant('DEFAULT_START_PAGE', $config->get('default_setting_start_page', "none"));
        $this->define_constant('DEFAULT_DISABLE_DELETE_PROMPT', $config->get('default_setting_disable_delete_prompt', false));
        $this->define_constant('DEFAULT_NO_FOLDER_ICONS', $config->get('default_setting_no_folder_icons', false));
        $this->define_constant('DEFAULT_SETTING_LANGUAGE', $config->get('default_setting_language', 'en'));
        $this->define_constant('DEFAULT_SMTP_COMPOSE_TYPE', $config->get('default_setting_smtp_compose_type', 0));
        $this->define_constant('DEFAULT_SMTP_AUTO_BCC', $config->get('default_setting_smtp_auto_bcc', false));
        $this->define_constant('DEFAULT_THEME', $config->get('default_setting_theme', 'default'));
        $this->define_constant('DEFAULT_UNREAD_EXCLUDE_WORDPRESS', $config->get('default_setting_unread_exclude_wordpress', false));
        $this->define_constant('DEFAULT_WORDPRESS_SINCE', $config->get('default_setting_wordpress_since', '-1 week'));
        $this->define_constant('DEFAULT_UNREAD_EXCLUDE_GITHUB', $config->get('default_setting_unread_exclude_github', false));
        $this->define_constant('DEFAULT_GITHUB_PER_SOURCE', $config->get('default_setting_github_limit', 20));
        $this->define_constant('DEFAULT_GITHUB_SINCE', $config->get('default_setting_github_since', '-1 week'));
        $this->define_constant('DEFAULT_INLINE_MESSAGE', $config->get('default_setting_inline_message', false));
        $this->define_constant('DEFAULT_INLINE_MESSAGE_STYLE', $config->get('default_setting_inline_message_style', 'right'));
        $this->define_constant('DEFAULT_ENABLE_KEYBOARD_SHORTCUTS', $config->get('default_setting_enable_keyboard_shortcuts', false));
        $this->define_constant('DEFAULT_ENABLE_SIEVE_FILTER', $config->get('default_setting_enable_sieve_filter', false));
        $this->define_constant('DEFAULT_ENABLE_COLLECT_ADDRESS_ON_SEND', $config->get('default_setting_enable_collect_address_on_send', false));
        $this->define_constant('DEFAULT_SETTING_ENABLE_EXCLUDE_AUTO_BCC', $config->get('default_setting_enable_exclude_auto_bcc', true));
    }

    private function define_constant($name, $value) {
        if (!defined($name)) {
            define($name, $value);
        }
    }

    /**
     * Sets required environment variables that are used within .env files
     */
    private function set_required_environment_variables($file) {
        $_ENV['CYPHT_DOTENV'] = APP_PATH . $file;
    }

    /**
     * Get a merge of environment variables $_ENV and $_SERVER.
     *
     * @return array
     */
    protected function get_environment_variables() {
        return array_merge($_ENV, $_SERVER);
    }
}

if (!function_exists('env')) {
    /**
     * Gets the value of an environment variable.
     *
     * @param  string  $key
     * @param  mixed   $default
     * @return mixed
     */
    function env($key, $default = null) {
        return getenv($key) ?: $default;
    }
}

if (!function_exists('merge_config_files')) {
    /**
     * Merge configuration arrays from PHP files in the specified folder.
     *
     * This function includes each PHP file in the specified folder and retrieves its array.
     * It then merges these arrays into a single configuration array, applying boolean conversion
     * for values that are represented as "true" or "false" strings.
     *
     * @param string $folder_path The path to the folder containing PHP configuration files.
     *
     * @return array The merged configuration array.
     */
    function merge_config_files($folder_path) {
        $configArray = [];

        // Get all PHP files in the specified folder
        $files = glob($folder_path . '/*.php');

        foreach ($files as $file) {
            $fileArray = process_config_array($file);
            $configArray = array_merge($configArray, $fileArray);
        }
        return $configArray;
    }
}

if (!function_exists('config')) {
    /**
     * Get configuration data for a single file
     *
     * @param string $file_name The path to PHP configuration file.
     *
     * @return array The configuration array.
     */
    function config($file_name) {
        $path = CONFIG_PATH.$file_name.'.php';
        return process_config_array($path);
    }
}

if (!function_exists('process_config_array')) {
    function process_config_array($filename) {
        $array = require $filename;
        if (is_array($array)) {
            return array_map(function ($value) {
                return is_array($value) ? $value : (
                    is_string($value) && mb_strtolower($value) === 'true' ? true : (
                        is_string($value) && mb_strtolower($value) === 'false' ? false : $value
                    )
                );
            }, $array);
        }
        return [];
    }
}
