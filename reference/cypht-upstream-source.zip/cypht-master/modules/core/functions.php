<?php

/**
 * Core modules
 * @package modules
 * @subpackage core
 */

/**
 * Format a value for display
 * @subpackage core/functions
 * @param string $name value name to find/format
 * @param array $haystack details to search for the value name
 * @param bool $type optional format type
 * @param mixed $default value to return if the name is not found
 * @return string
 */
if (!hm_exists('display_value')) {
function display_value($name, $haystack, $type=false, $default='') {
    if (!array_key_exists($name, $haystack)) {
        return $default;
    }
    $value = $haystack[$name];
    $res = false;
    if ($type) {
        $name = $type;
    }
    switch($name) {
        case 'from':
            $value = preg_replace("/(\<.+\>)/U", '', $value);
            $res = str_replace('"', '', $value);
            break;
        case 'date':
            $res = human_readable_interval($value);
            break;
        case 'time':
            $res = strtotime($value);
            break;
        default:
            $res = $value;
            break;
    }
    return $res;
}}

/**
 * Valid interface langs
 * @subpackage core/functions
 * @return array
 */
if (!hm_exists('interface_langs')) {
function interface_langs() {
    return array(
        'en' => 'English',
        'de' => 'German',
        'es' => 'Spanish',
        'fa' => 'Farsi',
        'fr' => 'French',
        'et' => 'Estonian',
        'id' => 'Indonesian',
        'it' => 'Italian',
        'ru' => 'Russian',
        'ro' => 'Romanian',
        'nl' => 'Dutch',
        'ja' => 'Japanese',
        'hu' => 'Hungarian',
        'pl' => 'Polish',
        'pt-BR' => 'Brazilian Portuguese',
        'az' => 'Azerbaijani',
        'zh-Hans' => 'Chinese Simplified',
        'zh-TW' => 'Traditional Chinese',
        'rw' => 'Kinyarwanda',
    );
}}

/**
 * Tranlate a human readable time string
 * @subpackage core/functions
 * @param string $str string to translate
 * @param object $output_mod Hm_Output_Module
 * @return string
 */
if (!hm_exists('translate_time_str')) {
function translate_time_str($str, $output_mod) {
    $parts = explode(',', $str);
    $res = array();
    foreach ($parts as $part) {
        $part = trim($part);
        if (preg_match("/(\d+)/", $part, $matches)) {
            $res[] = sprintf($output_mod->trans(preg_replace("/(\d+)/", '%d', $part)), $matches[1]);
        }
    }
    if (!empty($res)) {
        return implode(', ', $res);
    }
    return $str;
}}

/**
 * Format a data source to be a valid JS object
 * @subpackage core/functions
 * @param array $array values to format
 * @param object $output_mod Hm_Output_Module
 * @return string
 */
if (!hm_exists('format_data_sources')) {
function format_data_sources($array, $output_mod) {
    $result = '';
    $default = false;
    $groups = group_data_sources($array);
    foreach ($groups as $group_name => $sources) {
        $objects = array();
        foreach ($sources as $values) {
            $items = array();
            $custom = array_key_exists('type', $values) && $values['type'] == 'custom';
            foreach ($values as $name => $value) {
                if ($custom && $name == 'params') {
                    $value_output = json_encode($value);
                } else {
                    $value_output = '"'.$output_mod->html_safe($value).'"';
                }

                $items[] = $output_mod->html_safe($name).':'.$value_output;
            }
            $objects[] = '{'.implode(',', $items).'}';
        }
        $function = 'hm_data_sources';
        if ($group_name != 'default') {
            $function .= '_'.$group_name;
        }
        else {
            $default = true;
        }
        $result .= 'var '.$function.' = function() { return ['.implode(',', $objects).']; };';
    }
    if (!$default) {
        $result .= 'var hm_data_sources = function() { return []; };';
    }
    return $result;
}}

/**
 * Group data sources by the "group" attribute if it exists, otherwise use "default"
 * @subpackage core/functions
 * @param array $array list of data sources
 * @return array
 */
if (!hm_exists('group_data_sources')) {
function group_data_sources($array) {
    $groups = array();
    foreach($array as $vals) {
        $key = 'default';
        if (array_key_exists('group', $vals)) {
            $key = $vals['group'];
        }
        $groups[$key][] = $vals;
    }
    return $groups;
}}

/**
 * Determine if E-mail modules are active
 * @subpackage core/functions
 * @param array $mod_list list of active module sets
 * @return mixed
 */
if (!hm_exists('email_is_active')) {
function email_is_active($mod_list) {
    if (in_array('imap', $mod_list, true)) {
        return true;
    }
    return false;
}}

/**
 * Validate an E-mail using RFC 3696
 * @subpackage core/functions
 * @param string $val value to check
 * @param bool $allow_local flag to allow local addresses with no domain
 * @return bool
 */
if (!hm_exists('is_email_address')) {
function is_email_address($val, $allow_local=false) {
    $val = trim($val, "<>");
    $val = trim($val);

    if (!$val || mb_strlen($val) > 320) { // RFC 5321: max 320 chars
        return false;
    }

    $at_pos = mb_strrpos($val, '@');
    if ($at_pos === false) {
        // No @ symbol - only valid if $allow_local is true
        return $allow_local && validate_local_full($val);
    }

    if ($at_pos === 0 || $at_pos === mb_strlen($val) - 1) {
        return false; // @ at beginning or end
    }

    $local = mb_substr($val, 0, $at_pos);
    $domain = mb_substr($val, $at_pos + 1);

    if (!$local || mb_strlen($local) > 64) { // RFC 5321: max 64 chars for local part
        return false;
    }

    if (!$domain || mb_strlen($domain) > 255) { // RFC 5321: max 255 chars for domain
        return false;
    }

    // Validate local part
    if (!validate_local_full($local)) {
        return false;
    }

    // Validate domain (supports standard domains and domain literals)
    if (!validate_domain_full($domain)) {
        return false;
    }

    return true;
}}

/**
 * Do email domain part checks per RFC 3696 section 2
 * @subpackage core/functions
 * @param string $val value to check
 * @return bool
 */
if (!hm_exists('validate_domain_full')) {
function validate_domain_full($val) {
    if (!$val || mb_strlen($val) > 255) { // RFC 5321: max 255 chars
        return false;
    }

    // Check for domain literal (IP address in brackets)
    if (substr($val, 0, 1) === '[' && substr($val, -1) === ']') {
        $literal = substr($val, 1, -1);

        // IPv4: [192.168.1.1]
        if (preg_match('/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/', $literal)) {
            // Validate IPv4 ranges (0-255)
            $parts = explode('.', $literal);
            foreach ($parts as $part) {
                if ((int)$part > 255) {
                    return false;
                }
            }
            return true;
        }

        // IPv6: [IPv6:2001:db8::1]
        if (preg_match('/^IPv6:/i', $literal)) {
            $ipv6 = substr($literal, 5);

            // Basic IPv6 validation
            if (!$ipv6 || !preg_match('/^[a-fA-F0-9:]+$/', $ipv6)) {
                return false;
            }

            // Check for valid :: usage (at most one occurrence)
            $double_colon_count = substr_count($ipv6, '::');
            if ($double_colon_count > 1) {
                return false;
            }

            // Validate groups
            if ($double_colon_count === 1) {
                // With :: compression
                $segments = explode('::', $ipv6);
                $left_parts = $segments[0] ? explode(':', $segments[0]) : [];
                $right_parts = isset($segments[1]) && $segments[1] ? explode(':', $segments[1]) : [];
                $total_parts = count($left_parts) + count($right_parts);

                if ($total_parts >= 8) {
                    return false;
                }

                $parts = array_merge($left_parts, $right_parts);
            } else {
                // No :: compression, must have exactly 8 groups
                $parts = explode(':', $ipv6);
                if (count($parts) !== 8) {
                    return false;
                }
            }

            // Validate each part (1-4 hex digits)
            foreach ($parts as $part) {
                if ($part === '') continue;
                if (strlen($part) > 4 || !preg_match('/^[a-fA-F0-9]+$/', $part)) {
                    return false;
                }
            }

            return true;
        }

        return false; // Unknown domain literal format
    }

    // Standard domain validation
    // Split by dots to get labels
    $labels = explode('.', $val);
    if (count($labels) < 2) { // At least domain.tld
        return false;
    }

    foreach ($labels as $label) {
        if (!$label || mb_strlen($label) > 63) { // RFC 1035: max 63 chars per label
            return false;
        }

        // Labels cannot start or end with hyphen
        if (substr($label, 0, 1) === '-' || substr($label, -1) === '-') {
            return false;
        }

        // Allow alphanumeric, hyphen, and Unicode for IDN
        if (!preg_match('/^[a-zA-Z0-9\-\x{0080}-\x{FFFF}]+$/u', $label)) {
            return false;
        }
    }

    return true;
}}

/**
 * Do email local part checks per RFC 3696 section 3
 * @subpackage core/functions
 * @param string $val value to check
 * @return bool
 */
if (!hm_exists('validate_local_full')) {
function validate_local_full($val) {
    if (!$val || mb_strlen($val) > 64) { // RFC 5321: max 64 chars
        return false;
    }

    // Check if local part is quoted
    if (substr($val, 0, 1) === '"' && substr($val, -1) === '"') {
        // Quoted string - almost anything goes inside quotes
        $quoted = substr($val, 1, -1);

        // Check for unescaped quotes (quotes must be escaped with backslash)
        // This is a simplified check - proper implementation would need to handle escaped backslashes
        $temp = str_replace('\\\\', '', $quoted); // Remove escaped backslashes
        $temp = str_replace('\\"', '', $temp);     // Remove escaped quotes
        if (strpos($temp, '"') !== false) {
            return false; // Found unescaped quote
        }

        return true;
    }

    // Unquoted local part - standard rules
    // Cannot start or end with dot, no consecutive dots
    if (substr($val, 0, 1) === '.' || substr($val, -1) === '.' || strpos($val, '..') !== false) {
        return false;
    }

    // Allow only permitted characters for unquoted local part
    // A-Z a-z 0-9 . ! # $ % & ' * + - / = ? ^ _ ` { | } ~
    if (!preg_match('/^[a-zA-Z0-9.!#$%&\'*+\/=?^_`{|}~-]+$/', $val)) {
        return false;
    }

    return true;
}}

/**
 * Get Oauth2 server info
 * @subpackage core/functions
 * @param object $config site config object
 * @return array
 */
if (!hm_exists('get_oauth2_data')) {
function get_oauth2_data($config) {
    return [
        'gmail' => $config->get('gmail',[]),
        'outlook' => $config->get('outlook',[]),
        'office365' => $config->get('office365',[]),
    ];
}}

/**
 * Process user input for a site setting and prep it to be saved
 * @subpackage core/functions
 * @param string $type the name of the setting
 * @param object $handler hm hanndler module object
 * @param function $callback a function to sanitize the submitted value
 * @param mixed $default a default to use if callback is not submitted
 * @param bool $checkbox true if this is a checkbox setting
 * @return void
 */
if (!hm_exists('process_site_setting')) {
function process_site_setting($type, $handler, $callback=false, $default=false, $checkbox=false) {
    if ($checkbox) {
        list($success, $form) = $handler->process_form(array('save_settings'));
        if (array_key_exists($type, $handler->request->post)) {
            $form = array($type => $handler->request->post[$type]);
        }
        else {
            $form = array($type => false);
        }
    }
    else {
        list($success, $form) = $handler->process_form(array('save_settings', $type));
    }
    $new_settings = $handler->get('new_user_settings', array());
    $settings = $handler->get('user_settings', array());

    if ($success) {
        if (function_exists($callback)) {
            $result = $callback($form[$type], $type, $handler);
        }
        else {
            $result = $default;
        }
        $new_settings[$type.'_setting'] = $result;
    }
    else {
        $settings[$type] = $handler->user_config->get($type.'_setting', $default);
    }
    $handler->out('new_user_settings', $new_settings, false);
    $handler->out('user_settings', $settings, false);
}}

/**
 * Return a date for a "received since" value, or just sanitize it
 * @subpackage core/functions
 * @param string $val "received since" value to process
 * @param bool $validate flag to limit to validation only
 */
if (!hm_exists('process_since_argument')) {
function process_since_argument($val, $validate=false) {
    $date = false;
    $valid = false;
    if (in_array($val, array('-1 week', '-2 weeks', '-4 weeks', '-6 weeks', '-6 months', '-1 year', '-5 years'), true)) {
        $valid = $val;
        $date = date('j-M-Y', strtotime($val));
    }
    else {
        $val = 'today';
        $valid = $val;
        $date = date('j-M-Y');
    }
    if ($validate) {
        return $valid;
    }
    return $date;
}}

/**
 * Sanitize a "since" setting value for combined pages
 * @subpackage core/functions
 * @param string $val value to check
 * @return sanitized value
 */
if (!hm_exists('since_setting_callback')) {
function since_setting_callback($val) {
    return process_since_argument($val, true);
}}

/**
 * Sanitize a max per source value
 * @subpackage core/functions
 * @param int $val request max
 * @return sanitized max
 */
if (!hm_exists('max_source_setting_callback')) {
function max_source_setting_callback($val) {
    if ($val > MAX_PER_SOURCE || $val < 0) {
        return DEFAULT_PER_SOURCE;
    }
    return $val;
}}

/**
 * Save user settings from the session to permanent storage
 * @subpackage core/functions
 * @param object $handler hm handler module object
 * @param array $form sanitized user input
 * @param bool $logout true if this is a save + logout request
 * @return void
 */
if (!hm_exists('save_user_settings')) {
function save_user_settings($handler, $form, $logout) {
    $user = $handler->session->get('username', false);
    $path = $handler->config->get('user_settings_dir', false);

    if ($handler->session->auth($user, $form['password'])) {
        $pass = $form['password'];
    }
    else {
        Hm_Msgs::add('Incorrect password, could not save settings to the server', 'warning');
        $pass = false;
    }
    if ($user && $path && $pass) {
        try {
            $handler->user_config->save($user, $pass);
            $handler->session->set('changed_settings', array());
            if ($logout) {
                $handler->session->destroy($handler->request);
                Hm_Msgs::add('Saved user data on logout', 'info');
                Hm_Msgs::add('Session destroyed on logout', 'info');
            }
            else {
                Hm_Msgs::add('Settings saved', 'info');
            }
        } catch (Exception $e) {
            Hm_Msgs::add('Could not save settings: ' . $e->getMessage(), 'warning');
        }
    }

}}

/**
 * Setup commonly used modules for an ajax request
 * @subpackage core/functions
 * @param string $name the page id
 * @param string $source the module set name
 * @return void
 */
if (!hm_exists('setup_base_ajax_page')) {
function setup_base_ajax_page($name, $source=false) {
    add_handler($name, 'login', false, $source);
    add_handler($name, 'default_page_data', true, $source);
    add_handler($name, 'load_user_data', true, $source);
    add_handler($name, 'language',  true, $source);
    add_handler($name, 'date', true, $source);
    add_handler($name, 'http_headers', true, $source);
}}

/**
 * Setup commonly used modules for a page
 * @subpackage core/functions
 * @param string $name the page id
 * @param string $source the module set name
 * @param bool $use_layout true if this page uses the application layout
 * @return void
 */
if (!hm_exists('setup_base_page')) {
function setup_base_page($name, $source=false, $use_layout=true) {
    add_handler($name, 'stay_logged_in', false, $source);
    add_handler($name, 'login', false, $source);
    add_handler($name, 'default_page_data', true, $source);
    add_handler($name, 'load_user_data', true, $source);
    add_handler($name, 'message_list_type', true);
    add_handler($name, 'language',  true, $source);
    add_handler($name, 'process_search_terms', true, $source);
    add_handler($name, 'title', true, $source);
    add_handler($name, 'date', true, $source);
    add_handler($name, 'save_user_data', true, $source);
    add_handler($name, 'logout', true, $source);
    add_handler($name, 'http_headers', true, $source);
    add_handler($name, 'version_upgrade_checker', true, $source);

    add_output($name, 'header_start', false, $source);
    add_output($name, 'header_css', false, $source);
    add_output($name, 'header_content', false, $source);
    add_output($name, 'js_data', false, $source);
    add_output($name, 'js_search_data', true, $source);
    add_output($name, 'header_end', false, $source);
    add_output($name, 'msgs', false, $source);
    add_output($name, 'content_start', false, $source);
    if($use_layout) {
        add_output($name, 'login_start', false, $source);
        add_output($name, 'login', false, $source);
        add_output($name, 'login_end', false, $source);
        add_output($name, 'date', true, $source);
        add_output($name, 'folder_list_start', true, $source);
        add_output($name, 'folder_list_end', true, $source);
        add_output($name, 'content_section_start', true, $source);
        add_output($name, 'version_upgrade_checker', true, $source, 'content_section_start', 'after');
        add_output($name, 'content_section_end', true, $source);
        add_output($name, 'modals', true, $source);
        add_output($name, 'save_reminder', true, $source);
    }
    add_output($name, 'content_end', false, $source, 'page_js', 'after');
    add_output($name, 'page_js', false, $source);
}}

/**
 * Merge array details for folder sources
 * @subpackage core/functions
 * @param array $folder_sources list of folder list entries
 * @return array
 */
if (!hm_exists('merge_folder_list_details')) {
function merge_folder_list_details($folder_sources) {
    $res = array();
    if (!is_array($folder_sources)) {
        return $res;
    }
    foreach ($folder_sources as $vals) {
        if (array_key_exists($vals[0], $res)) {
            $res[$vals[0]] .= $vals[1];
        }
        else {
            $res[$vals[0]] = $vals[1];
        }
    }
    ksort($res);
    return $res;
}}

/**
 * Determine the correct TLS connection type to use based
 * on what this version of PHP supports
 * @return const
 */
if (!hm_exists('get_tls_stream_type')) {
function get_tls_stream_type() {
    $method = STREAM_CRYPTO_METHOD_TLS_CLIENT;
    if (defined('STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT')) {
        $method |= STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT;
        $method |= STREAM_CRYPTO_METHOD_TLSv1_1_CLIENT;
    }
    if (defined('STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT')) {
        $method |= STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT;
    }
    return $method;
}}

/**
 * List of valid start page options
 * @return array
 */
if (!hm_exists('start_page_opts')) {
function start_page_opts() {
    return array(
        'None' => 'none',
        'Home' => 'page=home',
        'Everything' => 'page=message_list&list_path=combined_inbox',
        'Unread' => 'page=message_list&list_path=unread',
        'Flagged' => 'page=message_list&list_path=flagged',
        'Compose' => 'page=compose'
    );
}}

/**
 * List of valid default sort order options
 * @return array
 */
if (!hm_exists('default_sort_order_opts')) {
function default_sort_order_opts() {
    return array(
        'arrival' => 'Arrival Date',
        'date' => 'Sent Date',
    );
}}

/**
 * See if a host + username is already in a server list
 * @param class $list class to check
 * @param int $id server id to get hostname from
 * @param string $user username to check for
 * @return bool
 */
if (!hm_exists('in_server_list')) {
function in_server_list($list, $id, $user) {
    $exists = false;
    $server = $list::dump($id);
    $name = false;
    if (is_array($server) && array_key_exists('server', $server)) {
        $name = $server['server'];
    }
    if (!$name) {
        return false;
    }
    foreach ($list::dump() as $server_id => $vals) {
        if ($id == $server_id) {
            continue;
        }
        if (array_key_exists('user', $vals) && $vals['user'] == $user && $vals['server'] == $name) {
            $exists = true;
            break;
        }
    }
    return $exists;
}}

/**
 * Perform a check on last added server
 * It gets deleted if already configured
 *
 * @param string $list class to process on check
 * @param string $user username to check for
 * @return bool
 */
if (!hm_exists('can_save_last_added_server')) {
function can_save_last_added_server($list, $user) {
    $servers = $list::dump(false, true);
    $ids = array_keys($servers);
    $new_id = array_pop($ids);
    if (in_server_list($list, $new_id, $user)) {
        $list::del($new_id);
        $type = explode('_', $list)[1];
        Hm_Msgs::add('This ' . $type . ' server and username are already configured', 'warning');
        return false;
    }
    return true;
}}

/**
 * @subpackage core/functions
 */
if (!hm_exists('profiles_by_smtp_id')) {
function profiles_by_smtp_id($profiles, $id) {
    $res = array();
    foreach ($profiles as $vals) {
        if (!is_array($vals)) {
            continue;
        }
        if ($vals['smtp_id'] == $id) {
            $res[] = $vals;
        }
    }
    return $res;
}}

/**
 * @subpackage cores/functions
 */
function get_special_folders($mod, $id) {
    $server = Hm_IMAP_List::dump($id);
    if (!$server) {
        return array();
    }
    $specials = $mod->user_config->get('special_imap_folders', array());
    foreach ($specials as $vals) {
        if (array_key_exists('imap_user', $vals) &&
            array_key_exists('imap_server', $vals) &&
            $server['server'] == $vals['imap_server'] &&
            $server['user'] == $vals['imap_user']) {

            return $vals;
        }
    }
    if (array_key_exists($id, $specials)) {
        return $specials[$id];
    }
    return array();
}

/**
 * @subpackage core/functions
 */
if (!hm_exists('check_file_upload')) {
function check_file_upload($request, $key) {
    if (!is_array($request->files) || !array_key_exists($key, $request->files)) {
        return false;
    }
    if (!is_array($request->files[$key]) || !array_key_exists('tmp_name', $request->files[$key])) {
        return false;
    }
    return true;
}}

function privacy_setting_callback($val, $key, $mod) {
    $setting = Hm_Output_privacy_settings::$settings[$key];
    $key .= '_setting';
    $user_setting = $mod->user_config->get($key);
    $update = $mod->request->post['update'] ?? false;
    $pop = $mod->request->post['pop'] ?? false;

    if ($update) {
        if ($pop) {
            $new_value = implode($setting['separator'], array_filter(explode($setting['separator'], $user_setting), function($item) use ($val) {
                return $item != $val;
            }));
        } else {
            $new_value = implode($setting['separator'], array_filter(array_merge(explode($setting['separator'], $user_setting), [$val])));
        }
        
        $mod->user_config->set($key, $new_value);

        $user_data = $mod->session->get('user_data', array());
        $user_data[$key] = $new_value;
        $mod->session->set('user_data', $user_data);
        $mod->session->record_unsaved('Privacy settings updated');

        return $new_value;
    }
    return $val;
}

if (!hm_exists('get_scheduled_date')) {
    function get_scheduled_date($format, $only_label = false) {
        switch ($format) {
            case 'later_in_day':
                $date_string = 'today 18:00';
                $label = 'Later in the day';
                break;
            case 'tomorrow':
                $date_string = '+1 day 08:00';
                $label = 'Tomorrow';
                break;
            case 'next_weekend':
                $date_string = 'next Saturday 08:00';
                $label = 'Next weekend';
                break;
            case 'next_week':
                $date_string = 'next week 08:00';
                $label = 'Next week';
                break;
            case 'next_month':
                $date_string = 'next month 08:00';
                $label = 'Next month';
                break;
            default:
                // Strip sub-second precision (e.g. .000Z) from ISO 8601 strings;
                // PHP's strtotime() does not support milliseconds.
                $date_string = preg_replace('/\.\d+(?=Z|[+\-]\d{2}:?\d{2}|$)/', '', $format);
                $label = 'Certain date';
                break;
        }

        $time = strtotime($date_string);

        if ($only_label) {
            return [$label, date('D, H:i', $time)];
        }

        return date('D, d M Y H:i T', $time);
    }
}


/**
 * @subpackage imap/functions
 */
if (!hm_exists('nexter_formats')) {
function nexter_formats() {
    $values = array(
        'tomorrow',
        'next_weekend',
        'next_week',
        'next_month'
    );
    if (date('H') <= 16) {
        array_push($values, 'later_in_day');
    }
    return $values;
}}

if (!hm_exists('schedule_dropdown')) {
function schedule_dropdown($output, $send_now = false, $list_control = false) {
    $values = nexter_formats();

    $txt = '';
    if ($send_now) {
        $txt .= '<div class="dropdown d-inline-block">
                <a class="hlink text-decoration-none dropdown-toggle' . ($list_control ? ' border btn btn-sm btn-light': ''). '" id="dropdownMenuNexterDate" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="true">'.$output->trans('Reschedule').'</a>';
    }
    $txt .= '<ul class="dropdown-menu nexter_dropdown schedule_dropdown" aria-labelledby="dropdownMenuNexterDate">';
    foreach ($values as $format) {
        $labels = get_scheduled_date($format, true);
        $txt .= '<li><a href="#" class="nexter_date_helper dropdown-item d-flex justify-content-between gap-5" data-value="'.$format.'"><span>'.$output->trans($labels[0]).'</span> <span class="text-end">'.$labels[1].'</span></a></li>';
    }
    $txt .= '<li><hr class="dropdown-divider"></li>';
    $txt .= '<li><label for="nexter_input_date" class="nexter_date_picker dropdown-item cursor-pointer">'.$output->trans('Pick a date').'</label>';
    $txt .= '<input id="nexter_input_date" type="datetime-local" min="'.date('Y-m-d\Th:m').'" class="nexter_input_date" style="visibility: hidden; position: absolute; height: 0;">';
    $txt .= '<input class="nexter_input" style="display:none;"></li>';
    if ($send_now) {
        $txt .= '<li><hr class="dropdown-divider"></li>';
        $txt .= '<li><a href="#" data-value="now" class="nexter_date_helper dropdown-item"">'.$output->trans('Send now').'</a></li>';
    }
    $txt .= '</ul>';
    if ($send_now) {
        $txt .= '</div>';
    }

    return $txt;
}}

/**
 * @subpackage imap/functions
 */
if (!hm_exists('parse_delayed_header')) {
    function parse_delayed_header($header, $name)
    {
        $header = str_replace("$name: ", '', $header);
        $result = [];
        foreach (explode(';', $header) as $keyValue)
        {
            $keyValue = trim($keyValue);
            $spacePos = strpos($keyValue, ' ');
            if ($spacePos > 0) {
                $result[rtrim(substr($keyValue, 0, $spacePos), ':')] = trim(substr($keyValue, $spacePos+1));
            } else {
                $result[$keyValue] = true;
            }
        }
        return $result;
    }
}

function getSettingsSectionOutput($section, $sectionLabel, $sectionIcon, $settingsOptions, $userSettings) {
    $res = '<tr><td data-target=".'. $section .'_setting" colspan="2" class="settings_subtitle cursor-pointer border-bottom p-2">'.
        '<i class="bi bi-'. $sectionIcon . ' fs-5 me-2"></i>'. $sectionLabel .'</td></tr>';
    foreach ($settingsOptions as $key => $setting) {
        $value = $userSettings[$key] ?? '';
        ['type' => $type, 'label' => $label, 'description' => $description] = $setting;

        if ($type === 'checkbox') {
            $input = '<input type="checkbox" id="'.$key.'" name="'.$key.'" '.($value ? 'checked' : '').' class="form-check-input me-2">';
        } else {
            $input = '<input type="'.$type.'" id="'.$key.'" name="'.$key.'" value="'.$value.'" class="form-control">';
        }

        $res .= "<tr class='{$section}_setting'>" .
        "<td class='d-block d-md-table-cell'><label for='$key'>$label</label></td>" .
        "<td class='d-block d-md-table-cell'>" .
            "<div class='d-flex align-items-center'>$input</div>" .
            "<div class='setting_description'>$description</div>" .
        "</td>" .
        "</tr>";
    }
    return $res;
}

function isPageConfigured($page) {
    $pages = array_keys(Hm_Handler_Modules::dump());
    return in_array($page, $pages);
}

/**
 * Encode a GET query array for the logout cancel-return parameter.
 * JSON cannot instantiate PHP objects, unlike serialize().
 * @subpackage core/functions
 * @param mixed $query
 * @return string
 */
if (!hm_exists('encode_logout_back_query')) {
function encode_logout_back_query($query) {
    if (!is_array($query)) {
        $query = array();
    }
    $safe = array();
    foreach ($query as $key => $value) {
        if (!is_string($key) && !is_int($key)) {
            continue;
        }
        if (is_scalar($value) || $value === null) {
            $safe[(string) $key] = $value;
        }
    }
    return base64_encode(json_encode($safe));
}}

/**
 * Decode a logout cancel-return parameter into a GET query array.
 * Rejects anything that is not a JSON object/array of scalars.
 * @subpackage core/functions
 * @param mixed $encoded
 * @return array
 */
if (!hm_exists('decode_logout_back_query')) {
function decode_logout_back_query($encoded) {
    if (!is_string($encoded) || $encoded === '') {
        return array();
    }
    $json = base64_decode($encoded, true);
    if ($json === false || $json === '') {
        return array();
    }
    $data = json_decode($json, true);
    if (!is_array($data)) {
        return array();
    }
    $safe = array();
    foreach ($data as $key => $value) {
        if (!is_string($key) && !is_int($key)) {
            continue;
        }
        if (is_scalar($value) || $value === null) {
            $safe[(string) $key] = $value;
        }
    }
    return $safe;
}}

