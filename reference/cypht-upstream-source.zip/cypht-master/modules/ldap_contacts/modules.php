<?php

/**
 * LDAP contact modules
 * @package modules
 * @subpackage ldap_contacts
 */

if (!defined('DEBUG_MODE')) { die(); }

require_once APP_PATH.'modules/ldap_contacts/hm-ldap-contacts.php';

/**
 * @subpackage ldap_contacts/handler
 */
class Hm_Handler_process_add_ldap_contact_from_message extends Hm_Handler_Module {
    public function process() {
        $ldap_config = $this->get('ldap_config');
        list($success, $form) = $this->process_form(array('contact_source', 'contact_value'));
        if (!$success) {
            return;
        }
        list($type, $source) = explode(':', $form['contact_source']);
        if ($type == 'ldap' && array_key_exists($source, $ldap_config)) {
            $addresses = Hm_Address_Field::parse($form['contact_value']);
            $config = $ldap_config[$source];
            if (count($config) == 0) {
                Hm_Msgs::add('Unable to add contact', 'danger');
                return;
            }
            $ldap = new Hm_LDAP_Contacts($config);
            if (!empty($addresses)) {
                $contacts = $this->get('contact_store');
                if ($ldap->connect()) {
                    foreach ($addresses as $vals) {
                        // Validate email address before adding to LDAP
                        if (empty($vals['email']) || !is_email_address($vals['email'], false)) {
                            Hm_Msgs::add('Invalid email address: ' . htmlspecialchars($vals['email']) . '. Please use a valid email address with a proper domain (e.g., user@example.com)', 'danger');
                            continue;
                        }
                        $atts = array('mail' => $vals['email'], 'objectclass' => $config['objectclass']);
                        if (array_key_exists('name', $vals) && trim($vals['name'])) {
                            $dn = sprintf('cn=%s,%s', $vals['name'], $config['base_dn']);
                            $atts['sn'] = $vals['name'];
                            $atts['cn'] = $vals['name'];
                            $atts['displayname'] = $vals['name'];
                        }
                        else {
                            $dn = sprintf('cn=%s,%s', str_replace(array('<', '>'), '', $vals['email']), $config['base_dn']);
                            $atts['cn'] = str_replace(array('<', '>'), '', $vals['email']);
                            $atts['sn'] = $atts['cn'];
                        }
                        if ($ldap->add($atts, $dn)) {
                            Hm_Msgs::add('Contact Added');
                        }
                        else {
                            Hm_Msgs::add('Unable to add contact', 'danger');
                        }
                    }
                }
            }
        }
    }
}

/**
 * @subpackage ldap_contacts/handler
 */
class Hm_Handler_process_delete_ldap_contact extends Hm_Handler_Module {
    public function process() {
        $contacts = $this->get('contact_store');
        $ldap_config = ldap_config($this->config);
        $sources = array_keys($ldap_config);
        list($success, $form) = $this->process_form(array('contact_type', 'contact_source', 'contact_id'));
        if ($success && $form['contact_type'] == 'ldap' && in_array($form['contact_source'], $sources, true)) {
            $config = $ldap_config[$form['contact_source']];
            
            // For LDAP contacts, skip contact ID lookup and use DN-based lookup directly
            $contacts = $this->get('contact_store');
            $dn = null;
            $contact = null;
            
            // Get DN from request data
            $target_dn = null;
            if (isset($this->request->post['ldap_dn']) && !empty($this->request->post['ldap_dn'])) {
                $target_dn = $this->request->post['ldap_dn'];
            } elseif (isset($this->request->get['dn'])) {
                $target_dn = Hm_LDAP_Contact::decodeDN($this->request->get['dn']);
            } elseif (isset($this->request->post['dn'])) {
                $target_dn = Hm_LDAP_Contact::decodeDN($this->request->post['dn']);
            }
            
            if ($target_dn) {
                $contact = Hm_LDAP_Contact::findByDN($contacts, $target_dn, $form['contact_source']);
                $dn = $target_dn;
            }
            
            if (!$contact || !$dn) {
                Hm_Msgs::add('Unable to find contact to delete', 'danger');
                return;
            }
            
            $ldap = new Hm_LDAP_Contacts($config);
            if ($ldap->connect()) {
                if ($ldap->delete($dn)) {
                    Hm_Msgs::add('Contact Deleted');
                    $this->out('contact_deleted', 1);
                }
                else {
                    if (is_resource($ldap->fh) || (is_object($ldap->fh) && get_class($ldap->fh) === 'LDAP\Connection')) {
                        $ldap_error = @ldap_error($ldap->fh);
                        $ldap_errno = @ldap_errno($ldap->fh);
                    } else {
                        $ldap_error = '';
                        $ldap_errno = 0;
                    }
                    
                    switch ($ldap_errno) {
                        case 50: // LDAP_INSUFFICIENT_ACCESS
                            Hm_Msgs::add('Permission denied: You do not have sufficient privileges to delete contacts from this LDAP directory', 'danger');
                            break;
                        case 66: // LDAP_NOT_ALLOWED_ON_NONLEAF
                            Hm_Msgs::add('Cannot delete: This contact has dependent entries that must be deleted first', 'danger');
                            break;
                        default:
                            Hm_Msgs::add('Could not delete contact', 'danger');
                            break;
                    }
                }
            }
            else {
                Hm_Msgs::add('Could not connect to LDAP server', 'danger');
            }
        }
    }
}

/**
 * @subpackage ldap_contacts/handler
 */
class Hm_Handler_process_ldap_fields extends Hm_Handler_Module {
    public function process() {
        $form = $this->get('ldap_entry_data', array());
        if (!is_array($form) || count($form) == 0) {
            return;
        }
        $config = ldap_config($this->config, $form['ldap_source']);
        $uidattr = isset($form['ldap_uidattr']) ? $form['ldap_uidattr'] : 'cn';
        $uid_val = '';

        if ($uidattr === 'uid') {
            if (!empty($form['ldap_uid'])) {
                $uid_val = $form['ldap_uid'];
            } else {
                Hm_Msgs::add('Username is required for UID-based contacts', 'danger');
                return;
            }
        } else {
            $uid_val = trim($form['ldap_first_name'].' '.$form['ldap_last_name']);
        }

        $dn = sprintf('%s=%s,%s', $uidattr, $uid_val, $config['base_dn']);

        $result = array('objectclass' => $config['objectclass']);
        // Always include cn as it's required by most objectclasses
        $cn = trim($form['ldap_first_name'].' '.$form['ldap_last_name']);
        $result['cn'] = $cn;
        
        if ($uidattr === 'uid' && !empty($form['ldap_uid'])) {
            $result['uid'] = $form['ldap_uid'];
        }
        
        $ldap_map = array(
            'ldap_first_name' => 'givenname',
            'ldap_last_name' => 'sn',
            'ldap_displayname' => 'displayname',
            'ldap_uid' => 'uid',
            'ldap_mail' => 'mail',
            'ldap_locality' => 'l',
            'ldap_state' => 'st',
            'ldap_street' => 'street',
            'ldap_postalcode' => 'postalcode',
            'ldap_title' => 'title',
            'ldap_phone' => 'telephonenumber',
            'ldap_fax' => 'facsimiletelephonenumber',
            'ldap_mobile' => 'mobile',
            'ldap_room' => 'roomnumber',
            'ldap_car' => 'carlicense',
            'ldap_org' => 'o',
            'ldap_org_unit' => 'ou',
            'ldap_org_dpt' => 'departmentnumber',
            'ldap_emp_num' => 'employeenumber',
            'ldap_emp_type' => 'employeetype',
            'ldap_lang' => 'preferredlanguage',
            'ldap_uri' => 'labeleduri'
        );
        foreach ($ldap_map as $name => $val) {
            // Skip uid attribute when uidattr is 'cn' to avoid empty uid values
            if ($name === 'ldap_uid' && $uidattr === 'cn') {
                continue;
            }
            // Validate email address if it's the mail field
            if ($name === 'ldap_mail') {
                $email = '';
                if (array_key_exists($name, $form)) {
                    $email = $form[$name];
                }
                elseif (array_key_exists($name, $this->request->post) && trim($this->request->post[$name])) {
                    $email = $this->request->post[$name];
                }
                if ($email && !is_email_address($email, false)) {
                    Hm_Msgs::add('Invalid email address. Please use a valid email address with a proper domain (e.g., user@example.com)', 'danger');
                    return;
                }
            }
            if (array_key_exists($name, $form)) {
                $result[$val] = $form[$name];
            }
            elseif (array_key_exists($name, $this->request->post) && trim($this->request->post[$name])) {
                $result[$val] = $this->request->post[$name];
            }
        }
        $this->out('entry_dn', $dn);
        $this->out('ldap_entry_data', $result, false);
        $this->out('ldap_config', $config, false);
    }
}

/**
 * @subpackage ldap_contacts/handler
 */
class Hm_Handler_process_update_ldap_server_ajax extends Hm_Handler_Module {
    public function process() {
        if ($this->get('ldap_action') != 'update') {
            return;
        }
        $entry = $this->get('ldap_entry_data', array());
        if (!is_array($entry) || count($entry) == 0) {
            return;
        }
        $dn = isset($this->request->post['ldap_dn']) && !empty($this->request->post['ldap_dn'])
            ? $this->request->post['ldap_dn']
            : $this->get('entry_dn');
        if (empty($dn)) {
            Hm_Msgs::add('Missing contact DN for update', 'danger');
            return;
        }
        $config = $this->get('ldap_config');
        $ldap = new Hm_LDAP_Contacts($config);
        if ($ldap->connect()) {
            if ($ldap->modify($entry, $dn)) {
                Hm_Msgs::add('Contact Updated');
                $this->out('contact_updated', 1);
            }
            else {
                Hm_Msgs::add('Unable to update contact', 'danger');
            }
        } else {
            Hm_Msgs::add('Unable to connect to LDAP server', 'danger');
        }
    }
}

/**
 * @subpackage ldap_contacts/handler
 */
class Hm_Handler_process_update_ldap_server extends Hm_Handler_Module {
    public function process() {
        if ($this->get('ldap_action') != 'update') {
            return;
        }
        $entry = $this->get('ldap_entry_data', array());
        if (!is_array($entry) || count($entry) == 0) {
            return;
        }
        $dn = get_ldap_value('dn', $this);
        $config = $this->get('ldap_config');
        $ldap = new Hm_LDAP_Contacts($config);
        if ($ldap->connect()) {
            if ($ldap->modify($entry, $dn)) {
                Hm_Msgs::add('Contact Updated');
                $this->save_hm_msgs();
                Hm_Dispatch::page_redirect($this->build_page_url('contacts'));
            }
            else {
                Hm_Msgs::add('Unable to update contact', 'danger');
            }
        } else {
            Hm_Msgs::add('Unable to connect to LDAP server', 'danger');
        }
    }
}

/**
 * @subpackage ldap_contacts/handler
 */
class Hm_Handler_process_add_to_ldap_server extends Hm_Handler_Module {
    public function process() {
        if ($this->get('ldap_action') != 'add') {
            return;
        }
        $entry = $this->get('ldap_entry_data', array());
        if (!is_array($entry) || count($entry) == 0) {
            return;
        }

        $config = $this->get('ldap_config');
        $dn = $this->get('entry_dn');
        $ldap = new Hm_LDAP_Contacts($config);
        if ($ldap->connect()) {
            if ($ldap->add($entry, $dn)) {
                Hm_Msgs::add('Contact Added');
                $this->out('contact_added', 1);
            }
            else {
                Hm_Msgs::add('Could not add contact, eror: '.$ldap->error(), 'danger');
            }
        } else {
            Hm_Msgs::add('Could not add contact: failed to connect to LDAP server', 'danger');
        }
    }
}

/**
 * @subpackage ldap_contacts/handler
 */
class Hm_Handler_process_update_ldap_contact extends Hm_Handler_Module {
    public function process() {
        list($success, $form) = $this->process_form(array('ldap_source', 'contact_source',
            'ldap_first_name', 'update_ldap_contact', 'ldap_last_name', 'ldap_mail', 'ldap_uidattr'));
        if ($success && $form['contact_source'] == 'ldap') {
            if (isset($form['ldap_uidattr']) && $form['ldap_uidattr'] === 'uid') {
                if (empty($this->request->post['ldap_uid'])) {
                    Hm_Msgs::add('Username is required when using UID attribute', 'danger');
                    return;
                }
                $form['ldap_uid'] = $this->request->post['ldap_uid'];
            } else {
                if (isset($this->request->post['ldap_uid'])) {
                    $form['ldap_uid'] = $this->request->post['ldap_uid'];
                }
            }
            
            $this->out('ldap_entry_data', $form, false);
            $this->out('ldap_action', 'update');
        }
    }
}

/**
 * @subpackage ldap_contacts/handler
 */
class Hm_Handler_process_add_ldap_contact extends Hm_Handler_Module {
    public function process() {
        list($success, $form) = $this->process_form(array('contact_source', 'ldap_first_name',
            'add_ldap_contact', 'ldap_last_name', 'ldap_mail', 'ldap_source', 'ldap_uidattr'));
        
        if ($success && $form['contact_source'] == 'ldap') {
            if (isset($form['ldap_uidattr']) && $form['ldap_uidattr'] === 'uid') {
                if (empty($this->request->post['ldap_uid'])) {
                    return;
                }
                $form['ldap_uid'] = $this->request->post['ldap_uid'];
            } else {
                if (isset($this->request->post['ldap_uid'])) {
                    $form['ldap_uid'] = $this->request->post['ldap_uid'];
                }
            }
            
            $this->out('ldap_entry_data', $form, false);
            $this->out('ldap_action', 'add');
        }
    }
}

/**
 * @subpackage ldap_contacts/handler
 */
class Hm_Handler_load_ldap_contacts extends Hm_Handler_Module {
    public function process() {
        $contacts = $this->get('contact_store');
        list($contacts, $ldap_config) = fetch_ldap_contacts($this->config, $this->user_config, $contacts);
        $this->append('contact_sources', 'ldap');
        $edit = false;
        $sources = array();
        foreach ($ldap_config as $name => $vals) {
            if (is_array($vals) && array_key_exists('read_write', $vals) && $vals['read_write']) {
                $this->append('contact_edit', sprintf('ldap:%s', $name));
                $sources[] = $name;
                $edit = true;
            }
        }
        $this->out('ldap_edit', $edit);
        $this->out('ldap_sources', $sources);
        $this->out('contact_store', $contacts, false);
        $this->out('ldap_config', $ldap_config, false);
    }
}
/**
 * @subpackage ldap_contacts/handler
 */
class Hm_Handler_load_edit_ldap_contact extends Hm_Handler_Module {
    public function process() {
        $ldap_config = $this->get('ldap_config');

        if (array_key_exists('contact_source', $this->request->get) &&
            array_key_exists('contact_type', $this->request->get) &&
            $this->request->get['contact_type'] == 'ldap' &&
            array_key_exists($this->request->get['contact_source'], $ldap_config) &&
            array_key_exists('contact_id', $this->request->get)) {
            $contacts = $this->get('contact_store');
            $contact_id = $this->request->get['contact_id'];
            $contact_source = $this->request->get['contact_source'];
            
            
            $target_dn = isset($this->request->get['dn']) ? Hm_LDAP_Contact::decodeDN($this->request->get['dn']) : null;
            
            if ($target_dn) {
                $contact = Hm_LDAP_Contact::findByDN($contacts, $target_dn, $contact_source);
                if ($contact) {
                    $current = $contact->export();
                    $current['id'] = $contact_id;
                    $this->out('current_ldap_contact', $current);
                    $this->handler_response['ldap_edit'] = true;
                }
            }
            
        } else {
            $missing = array();
            if (!array_key_exists('contact_source', $this->request->get)) $missing[] = 'contact_source';
            if (!array_key_exists('contact_type', $this->request->get)) $missing[] = 'contact_type';
            if (!array_key_exists('contact_id', $this->request->get)) $missing[] = 'contact_id';
            if (array_key_exists('contact_source', $this->request->get) && !array_key_exists($this->request->get['contact_source'], $ldap_config)) $missing[] = 'ldap_config_for_source';
            
            if (DEBUG_MODE) {
                Hm_Debug::add("LDAP Edit: Handler skipped due to missing: " . implode(', ', $missing));
            }
        }
    }
}

/**
 * @subpackage ldap_contacts/handler
 */
class Hm_Handler_process_ldap_auth_settings extends Hm_Handler_Module {
    public function process() {
        if (!array_key_exists('save_settings', $this->request->post)) {
            return;
        }
        $connections = $this->get('ldap_contact_connections');
        $users = array();
        $passwords = array();
        $results = $connections;
        if (array_key_exists('ldap_usernames', $this->request->post)) {
            $users = $this->request->post['ldap_usernames'];
        }
        if (array_key_exists('ldap_passwords', $this->request->post)) {
            $passwords = $this->request->post['ldap_passwords'];
        }
        foreach ($connections as $name => $vals) {
            if (array_key_exists($name, $users)) {
                $results[$name]['user'] = $users[$name];
            }
            if (array_key_exists($name, $passwords)) {
                $results[$name]['pass'] = $passwords[$name];
            }
        }
        if (count($results) > 0) {
            $new_settings = $this->get('new_user_settings');
            $new_settings['ldap_contacts_auth_setting'] = $results;
            $this->out('new_user_settings', $new_settings, false);
        }
    }
}

/**
 * @subpackage ldap_contacts/handler
 */
class Hm_Handler_load_ldap_settings extends Hm_Handler_Module {
    public function process() {
        $connections = array();
        foreach (ldap_config($this->config) as $name => $vals) {
            if (is_array($vals) && array_key_exists('auth', $vals) && $vals['auth']) {
                if ((!array_key_exists('user', $vals) || !$vals['user']) &&
                    (!array_key_exists('pass', $vals) || !$vals['pass'])) {
                    $connections[$name] = $vals;
                }
            }
        }
        $this->out('ldap_contacts_auth', $this->user_config->get('ldap_contacts_auth_setting'));
        $this->out('ldap_contact_connections', $connections);
    }
}

/**
 * @subpackage ldap_contacts/handler
 */
class Hm_Handler_ldap_send_to_contact extends Hm_Handler_Module {
    public function process() {
        if (!$this->get('compose_draft') && 
            array_key_exists('contact_id', $this->request->get) &&
            array_key_exists('contact_type', $this->request->get) &&
            array_key_exists('contact_source', $this->request->get) &&
            array_key_exists('dn', $this->request->get) &&
            $this->request->get['contact_type'] == 'ldap') {
            
            $contacts = $this->get('contact_store');
            $contact_id = $this->request->get['contact_id'];
            $contact_source = $this->request->get['contact_source'];
            
            // For LDAP contacts, use DN-based lookup directly (contact_id is unreliable for LDAP)
            $target_dn = Hm_LDAP_Contact::decodeDN($this->request->get['dn']);
            $contact = Hm_LDAP_Contact::findByDN($contacts, $target_dn, $contact_source);
            
            if ($contact) {
                $to = sprintf('%s <%s>', $contact->value('display_name'), $contact->value('email_address'));
                $this->out('compose_draft', array('draft_to' => $to, 'draft_subject' => '', 'draft_body' => ''));
            }
        }
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_auth_settings extends Hm_Output_Module {
    protected function output() {
        $connections = $this->get('ldap_contact_connections', array());
        $auths = $this->get('ldap_contacts_auth', array());
        if (count($connections) > 0) {
            $res = '<tr><td data-target=".ldap_settings" colspan="2" class="settings_subtitle cursor-pointer border-bottom p-2">'.
                '<i class="bi bi-people-fill fs-5 me-2"></i>'.
                $this->trans('LDAP Addressbooks').'</td></tr>';
            foreach ($connections as $name => $con) {
                $user = '';
                $pass = false;
                if (array_key_exists($name, $auths)) {
                    $user = $auths[$name]['user'];
                    if (array_key_exists('pass', $auths[$name]) && $auths[$name]['pass']) {
                        $pass = true;
                    }
                }
                $res .= '<tr class="ldap_settings"><td>'.$this->html_safe($name).'</td><td>';
                $res .= '<input autocomplete="username" type="text" value="'.$user.'" name="ldap_usernames['.$this->html_safe($name).']" ';
                $res .= 'placeholder="'.$this->trans('Username').'" class="form-control mb-2" /> <input type="password"  class="form-control"';
                if ($pass) {
                    $res .= 'disabled="disabled" placeholder="'.$this->trans('Password saved').'" ';
                    $res .= 'name="ldap_passwords['.$this->html_safe($name).']" /> <input type="button" ';
                    $res .= 'value="'.$this->trans('Unlock').'" class="ldap_password_change btn btn-primary" /></td></tr>';
                }
                else {
                    $res .= 'autocomplete="new-password" placeholder="'.$this->trans('Password').'" ';
                    $res .= 'name="ldap_passwords['.$this->html_safe($name).']" /></td></tr>';
                }
            }
            return $res;
        }
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_contact_form_end extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        
        $res = '</div>';
        $res .= '</div>';
        $res .= '</div>';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_first_name extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $name = get_ldap_value('givenname', $this);
        $current = $this->get('current_ldap_contact');
        $is_edit = !empty($current);
        
        if ($is_edit) {
            $uidattr = get_ldap_value('uidattr', $this);
            if ($uidattr === 'cn') {
                // For CN-based contacts, make first name read-only to prevent DN conflicts
                return '<div class="col-md-6 mb-3">'.
                    '<label for="ldap_first_name" class="form-label">'.$this->trans('First Name').' ('.$this->trans('Read Only').')</label>'.
                    '<input placeholder="'.$this->trans('First Name').'" id="ldap_first_name" '.
                    'type="text" name="ldap_first_name" value="'.$this->html_safe($name).'" class="form-control" readonly />'.
                    '</div>';
            }
        }else{
            $res = '<div class="col-md-6 mb-3">';
            $res .= '<label for="ldap_first_name" class="form-label">' . $this->trans('First Name') . ' <span class="text-danger">*</span></label>';
            $res .= '<input required placeholder="' . $this->trans('First Name') . '" id="ldap_first_name" type="text" name="ldap_first_name" value="'.$this->html_safe($name).'" class="form-control custom-input">';
            $res .= '</div>';
        }

        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_submit extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $label = 'Add';
        $name = 'add_ldap_contact';
        if ($this->get('current_ldap_contact')) {
            $label = 'Update';
            $name = 'update_ldap_contact';
        }

        //close Additional Information Section
        $res = '</div>';
        $res .= '</div>';
        
        $res .= '<input name="'.$name.'" type="hidden" value="'.$this->trans($label).'" class="btn btn-primary custom-btn-primary me-1" />';
        $res .= '</form>';
        $res .= '</div>';

        $res .= '<div class="modal-footer custom-modal-footer">';
        $res .= '<button type="button" class="reset_contact btn btn-secondary custom-btn-secondary" data-bs-dismiss="modal">';
        $res .= $this->trans('Cancel');
        $res .= '</button>';
        $res .= '<button type="submit" class="btn btn-primary custom-btn-primary" id="submit-ldap-contact-btn">';
        $res .= $this->trans($label);
        $res .= '</button>';
        $res .= '</div>';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_last_name extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $name = get_ldap_value('sn', $this);
        $current = $this->get('current_ldap_contact');
        $is_edit = !empty($current);
        
        if ($is_edit) {
            $uidattr = get_ldap_value('uidattr', $this);
            if ($uidattr === 'cn') {
                // For CN-based contacts, make last name read-only to prevent DN conflicts
                return '<div class="col-md-6 mb-3">'.
                    '<label for="ldap_last_name">'.$this->trans('Last Name').' ('.$this->trans('Read Only').')</label>'.
                    '<input placeholder="'.$this->trans('Last Name').'" id="ldap_last_name" type="text" '.
                    'name="ldap_last_name" value="'.$this->html_safe($name).'" class="form-control" readonly />'.
                    '</div>';
            }
        }else {
            $res = '<div class="col-md-6 mb-3">';
            $res .= '<label for="ldap_last_name" class="form-label">' . $this->trans('Last Name') . ' <span class="text-danger">*</span></label>';
            $res .= '<input required placeholder="' . $this->trans('Last Name') . '" id="ldap_last_name" type="text" name="ldap_last_name" value="" class="form-control custom-input">';
            $res .= '</div>';
        }
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_title extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $title = get_ldap_value('title', $this);
        $res = '<div class="col-md-4 mb-3">';
        $res .= '<label for="ldap_title" class="form-label">' . $this->trans('Title') . '</label>';
        $res .= '<input placeholder="' . $this->trans('Title') . '" id="ldap_title" type="text" name="ldap_title" value="'.$this->html_safe($title).'" class="form-control custom-input">';
        $res .= '</div>';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_contact_form_start extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $sources = $this->get('ldap_sources');
        $title = $this->trans('Add LDAP');
        $current = $this->get('current_ldap_contact');
        $current_source = false;
        if ($current) {
            $current_source = $current['source'];
            $title = sprintf($this->trans('Update LDAP - %s'), $this->html_safe($current_source));
        }
        $res = '<div class="modal fade" id="ldapContactModal" tabindex="-1" aria-labelledby="ldapContactModalLabel" aria-hidden="true">';
        $res .= '<div class="modal-dialog modal-dialog-centered modal-xl">';
        $res .= '<div class="modal-content custom-modal-content">';
        
        $res .= '<div class="modal-header custom-modal-header">';
        $res .= '<h5 class="modal-title d-flex align-items-center" id="ldapContactModalLabel">';
        $res .= '<div class="modal-icon-wrapper me-2">';
        $res .= '<i class="bi bi-person-plus-fill" style="font-size: 24px;"></i>';
        $res .= '</div>';
        $res .= $title;
        $res .= '</h5>';
        $res .= '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>'; 
        $res .= '</div>';

        $res .= '<div class="modal-body custom-modal-body">';
        
        $res .= '<form class="ldap-contact-form" id="ldap-contact-form" method="POST" action="">';
        $res .= '<input type="hidden" name="hm_page_key" value="'.$this->html_safe(Hm_Request_Key::generate()).'" />';
        $res .= '<input type="hidden" name="contact_source" value="ldap" />';
        $res .= '<div class="form-section mb-4">';
        $res .= '<h6 class="form-section-title">' . $this->trans('Basic Information') . '</h6>';
        $res .= '<div class="row">';
        if($current_source) {
            $res .= '<input type="hidden" name="ldap_source" value="'.$this->html_safe($current_source).'">';
        }else{
            $res .= '<div class="col-md-6 mb-3">';
            $res .= '<label for="ldap_source" class="form-label">' . $this->trans('Source') . '</label>';
            $res .= '<select id="ldap_source" name="ldap_source" class="form-select custom-input">';
            foreach ($sources as $name) {
                $res .= '<option value="'.$this->html_safe($name).'">'.$this->html_safe($name).'</option>';
            }
            $res .= '</select>';
            $res .= '</div>';
        }
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_displayname extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('displayname', $this);

        $res = '<div class="col-md-6 mb-3">';
        $res .= '<label for="ldap_displayname" class="form-label">' . $this->trans('Display Name') . '</label>';
        $res .= '<input placeholder="' . $this->trans('Display Name') . '" id="ldap_displayname" type="text" name="ldap_displayname" value="'.$this->html_safe($val).'" class="form-control custom-input">';
        $res .= '</div>';

        //close Basic Information group
        $res .= '</div>';
        $res .= '</div>';

        //start Contact Information Section
        $res .= '<div class="form-section mb-4">';
        $res .= '<h6 class="form-section-title">' . $this->trans('Contact Information') . '</h6>';
        $res .= '<div class="row">';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */

class Hm_Output_ldap_form_uidattr extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('uidattr', $this);
        $current = $this->get('current_ldap_contact');
        $is_edit = !empty($current);
        $options = array('cn', 'uid');
        if ($is_edit) {
                  $res = '<div class="col-md-6 mb-3">'.
                '<label for="ldap_uidattr_display" class="form-label">'.$this->trans('UID Attribute').' ('.$this->trans('Read Only').')</label>'.
                '<input placeholder="'.$this->trans('UID Attribute').'" id="ldap_uidattr_display" type="text" '.
                'value="'.$this->html_safe($this->trans($val)).'" class="form-control custom-input" readonly />'.
                '</div>';
            
            $res .= '<input type="hidden" name="ldap_uidattr" value="'.$this->html_safe($val).'" />';
            
            $uid_val = get_ldap_value('uid', $this);
            
            // Username field - also read-only in edit mode
            if ($val === 'uid' && !empty($uid_val)) {
                $res .= '<div class="col-md-6 mb-3">'.
                    '<label for="ldap_uid_display" class="form-label">'.$this->trans('Username').' ('.$this->trans('Read Only').')</label>'.
                    '<input placeholder="'.$this->trans('Username').'" id="ldap_uid_display" type="text" '.
                    'value="'.$this->html_safe($uid_val).'" class="form-control custom-input" readonly />'.
                    '</div>';
                
                $res .= '<input type="hidden" name="ldap_uid" value="'.$this->html_safe($uid_val).'" />';
            }

        }else {
            $res = '<div class="col-md-6 mb-3">';
            $res .= '<label for="ldap_uidattr" class="form-label">' . $this->trans('UID Attribute') . '</label>';
            $res .= '<select id="ldap_uidattr" name="ldap_uidattr" class="form-select custom-input">';
            foreach ($options as $opt) {
                $selected = ($val == $opt) ? ' selected' : '';
                $res .= '<option value="'.$this->html_safe($opt).'"'.$selected.'>'.$this->trans($opt).'</option>';
            }
            $res .= '</select>';
            $res .= '</div>';

            if ($val === 'uid' && !empty($uid_val)) {
                $res = '<div class="col-md-6 mb-3 d-none" id="ldap_uid_field_wrapper">';
                $res .= '<label for="ldap_uid" class="form-label">' . $this->trans('Username') . '</label>';
                $res .= '<input placeholder="' . $this->trans('Username') . '" id="ldap_uid" type="text" name="ldap_uid" value="" class="form-control custom-input" autocomplete="username">';
                $res .= '</div>';
            }
        }

        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_dn_display extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $current = $this->get('current_ldap_contact');
        if (empty($current)) {
            return; // Only show DN in edit mode
        }
        
        $dn = get_ldap_value('dn', $this);
        if (empty($dn)) {
            return;
        }
        $res = '<div class="col-md-12 mb-3">';
        $res .= '<label for="ldap_dn_display" class="form-label">' . $this->trans('Distinguished Name') . ' (' . $this->trans('Read Only') . ')</label>';
        $res .= '<input type="text" id="ldap_dn_display" class="form-control" value="' . $this->html_safe($dn) . '" readonly />';
        $res .= '<input type="hidden" name="ldap_dn" value="' . $this->html_safe($dn) . '" />';
        $res .= '</div>';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_mail extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('email_address', $this);

        $res = '<div class="col-md-6 mb-3">';
        $res .= '<label for="ldap_mail" class="form-label">' . $this->trans('E-mail Address') . ' <span class="text-danger">*</span></label>';
        $res .= '<input required placeholder="' . $this->trans('E-mail Address') . '" id="ldap_mail" type="email" name="ldap_mail" value="'.$this->html_safe($val).'" class="form-control custom-input">';
        $res .= '</div>';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_phone extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('phone_number', $this);
        $res = '<div class="col-md-4 mb-3">';
        $res .= '<label for="ldap_phone" class="form-label">' . $this->trans('Telephone Number') . '</label>';
        $res .= '<input placeholder="' . $this->trans('Telephone Number') . '" id="ldap_phone" type="text" name="ldap_phone" value="'.$this->html_safe($val).'" class="form-control custom-input">';
        $res .= '</div>';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_fax extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('facsimiletelephonenumber', $this);
        $res = '<div class="col-md-4 mb-3">';
        $res .= '<label for="ldap_fax" class="form-label">' . $this->trans('Fax Number') . '</label>';
        $res .= '<input placeholder="' . $this->trans('Fax Number') . '" id="ldap_fax" type="text" name="ldap_fax" value="'.$this->html_safe($val).'" class="form-control custom-input">';
        $res .= '</div>';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_mobile extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('mobile', $this);

        $res = '<div class="col-md-4 mb-3">';
        $res .= '<label for="ldap_mobile" class="form-label">' . $this->trans('Mobile Number') . '</label>';
        $res .= '<input placeholder="' . $this->trans('Mobile Number') . '" id="ldap_mobile" type="text" name="ldap_mobile" value="'.$this->html_safe($val).'" class="form-control custom-input">';
        $res .= '</div>';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_room extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('roomnumber', $this);
        $res = '<div class="col-md-4 mb-3">';
        $res .= '<label for="ldap_room" class="form-label">' . $this->trans('Room Number') . '</label>';
        $res .= '<input placeholder="' . $this->trans('Room Number') . '" id="ldap_room" type="text" name="ldap_room" value="'.$this->html_safe($val).'" class="form-control custom-input">';
        $res .= '</div>';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_car extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('carlicense', $this);
        $res = '<div class="col-md-6 mb-3">';
        $res .= '<label for="ldap_car" class="form-label">' . $this->trans('License Plate Number') . '</label>';
        $res .= '<input placeholder="' . $this->trans('License Plate Number') . '" id="ldap_car" type="text" name="ldap_car" value="'.$this->html_safe($val).'" class="form-control custom-input">';
        $res .= '</div>';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_org extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('o', $this);

        $res = '<div class="col-md-6 mb-3">';
        $res .= '<label for="ldap_org" class="form-label">' . $this->trans('Organization') . '</label>';
        $res .= '<input placeholder="' . $this->trans('Organization') . '" id="ldap_org" type="text" name="ldap_org" value="'.$this->html_safe($val).'" class="form-control custom-input">';
        $res .= '</div>';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_org_unit extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('ou', $this);
        $res = '<div class="col-md-6 mb-3">';
        $res .= '<label for="ldap_org_unit" class="form-label">' . $this->trans('Organization Unit') . '</label>';
        $res .= '<input placeholder="' . $this->trans('Organization Unit') . '" id="ldap_org_unit" type="text" name="ldap_org_unit" value="'.$this->html_safe($val).'" class="form-control custom-input">';
        $res .= '</div>';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_org_dpt extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('departmentnumber', $this);
        $res = '<div class="col-md-4 mb-3">';
        $res .= '<label for="ldap_org_dpt" class="form-label">' . $this->trans('Department Number') . '</label>';
        $res .= '<input placeholder="' . $this->trans('Department Number') . '" id="ldap_org_dpt" type="text" name="ldap_org_dpt" value="'.$this->html_safe($val).'" class="form-control custom-input">';
        $res .= '</div>';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_emp_num extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('employeenumber', $this);
        $res = '<div class="col-md-6 mb-3">';
        $res .= '<label for="ldap_emp_num" class="form-label">' . $this->trans('Employee Number') . '</label>';
        $res .= '<input placeholder="' . $this->trans('Employee Number') . '" id="ldap_emp_num" type="text" name="ldap_emp_num" value="'.$this->html_safe($val).'" class="form-control custom-input">';
        $res .= '</div>';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_emp_type extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('employeetype', $this);
        $res = '<div class="col-md-6 mb-3">';
        $res .= '<label for="ldap_emp_type" class="form-label">' . $this->trans('Employment Type') . '</label>';
        $res .= '<input placeholder="' . $this->trans('Employment Type') . '" id="ldap_emp_type" type="text" name="ldap_emp_type" value="'.$this->html_safe($val).'" class="form-control custom-input">';
        $res .= '</div>';

        //close Organization group
        $res .= '</div>';
        $res .= '</div>';
        
        //Start Additional Information Section
        $res .= '<div class="form-section mb-4">';
        $res .= '<h6 class="form-section-title">' . $this->trans('Additional Information') . '</h6>';
        $res .= '<div class="row">';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_lang extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('preferredlanguage', $this);

        $res = '<div class="col-md-6 mb-3">';
        $res .= '<label for="ldap_lang" class="form-label">' . $this->trans('Language') . '</label>';
        $res .= '<input placeholder="' . $this->trans('Language') . '" id="ldap_lang" type="text" name="ldap_lang" value="'.$this->html_safe($val).'" class="form-control custom-input">';
        $res .= '</div>';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_uri extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('labeleduri', $this);

        $res = '<div class="col-md-12 mb-3">';
        $res .= '<label for="ldap_uri" class="form-label">' . $this->trans('Website') . '</label>';
        $res .= '<input placeholder="' . $this->trans('Website') . '" id="ldap_uri" type="text" name="ldap_uri" value="'.$this->html_safe($val).'" class="form-control custom-input">';
        $res .= '</div>';
        
        //close Contact Information group
        $res .= '</div>';
        $res .= '</div>';

        //Start Address Information Section
        $res .= '<div class="form-section mb-4">';
        $res .= '<h6 class="form-section-title">' . $this->trans('Address Information') . '</h6>';
        $res .= '<div class="row">';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_locality extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('l', $this);
        $res = '<div class="col-md-6 mb-3">';
        $res .= '<label for="ldap_locality" class="form-label">' . $this->trans('Locality') . '</label>';
        $res .= '<input placeholder="' . $this->trans('Locality') . '" id="ldap_locality" type="text" name="ldap_locality" value="'.$this->html_safe($val).'" class="form-control custom-input">';
        $res .= '</div>';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_street extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('street', $this);
        $res = '<div class="col-md-6 mb-3">';
        $res .= '<label for="ldap_street" class="form-label">' . $this->trans('Street') . '</label>';
        $res .= '<input placeholder="' . $this->trans('Street') . '" id="ldap_street" type="text" name="ldap_street" value="'.$this->html_safe($val).'" class="form-control custom-input">';
        $res .= '</div>';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_state extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('st', $this);
        $res = '<div class="col-md-6 mb-3">';
        $res .= '<label for="ldap_state" class="form-label">' . $this->trans('State') . '</label>';
        $res .= '<input placeholder="' . $this->trans('State') . '" id="ldap_state" type="text" name="ldap_state" value="'.$this->html_safe($val).'" class="form-control custom-input">';
        $res .= '</div>';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/output
 */
class Hm_Output_ldap_form_postalcode extends Hm_Output_Module {
    protected function output() {
        if (!$this->get('ldap_edit')) {
            return;
        }
        $val = get_ldap_value('postalcode', $this);
        $res = '<div class="col-md-6 mb-3">';
        $res .= '<label for="ldap_postalcode" class="form-label">' . $this->trans('Postal Code') . '</label>';
        $res .= '<input placeholder="' . $this->trans('Postal Code') . '" id="ldap_postalcode" type="text" name="ldap_postalcode" value="'.$this->html_safe($val).'" class="form-control custom-input">';
        $res .= '</div>';

        //close Address Information group
        $res .= '</div>';
        $res .= '</div>';

        //Start Organization Information Section
        $res .= '<div class="form-section mb-4">';
        $res .= '<h6 class="form-section-title">' . $this->trans('Organization Information') . '</h6>';
        $res .= '<div class="row">';
        return $res;
    }
}

/**
 * @subpackage ldap_contacts/functions
 */
if (!hm_exists('get_ldap_value')) {
function get_ldap_value($fld, $mod) {
    $current = $mod->get('current_ldap_contact');
    if (!is_array($current) || !array_key_exists('all_fields', $current)) {
        return '';
    }
    
    if ($fld === 'uidattr') {
        $all_fields = $current['all_fields'];
        if (isset($all_fields['dn'])) {
            $dn = $all_fields['dn'];
            if (strpos($dn, 'uid=') === 0) {
                return 'uid';
            } elseif (strpos($dn, 'cn=') === 0) {
                return 'cn';
            }
        }
        if (isset($all_fields['uid']) && !empty($all_fields['uid'])) {
            return 'uid';
        }
        return 'uid';
    }
    
    if (array_key_exists($fld, $current['all_fields'])) {
        return $current['all_fields'][$fld];
    }
    if (array_key_exists($fld, $current)) {
        return $current[$fld];
    }
    return '';
}}

/**
 * @subpackage ldap_contacts/functions
 */
if (!hm_exists('fetch_ldap_contacts')) {
function fetch_ldap_contacts($config, $user_config, $contact_store, $session=false) {
    $ldap_config = ldap_config($config);
    $ldap_config = ldap_add_user_auth($ldap_config, $user_config->get('ldap_contacts_auth_setting', array()));
    if (count($ldap_config) > 0) {
        foreach ($ldap_config as $name => $vals) {
            if (is_array($vals)) {
                $vals['name'] = $name;
            }
            $ldap = new Hm_LDAP_Contacts($vals);

            if ($ldap->connect()) {
                $contacts = $ldap->fetch();
                if (count($contacts) > 0) {
                    $contact_store->import($contacts);
                }
            }
        }
    }
    return array($contact_store, $ldap_config);
}}

/**
 * @subpackage ldap_contacts/functions
 */
if (!hm_exists('ldap_add_user_auth')) {
function ldap_add_user_auth($ldap_config, $auths) {
    if (!is_array($ldap_config) || !is_array($auths)) {
        return $ldap_config;
    }
    foreach ($auths as $name => $vals) {
        if (array_key_exists($name, $ldap_config)) {
            if (array_key_exists('user', $vals)) {
                if (!$vals['user']) {
                    continue;
                }
                $uid_attr = $ldap_config[$name]['ldap_uid_attr'] ?? 'uid';
                $user = sprintf('%s=%s,%s', $uid_attr, $vals['user'], $ldap_config[$name]['base_dn']);
                $ldap_config[$name]['user'] = $user;
            }
            if (array_key_exists('pass', $vals)) {
                $ldap_config[$name]['pass'] = $vals['pass'];
            }
        }
    }
    return $ldap_config;
}}

/**
 * @subpackage ldap_contacts/functions
 */
if (!hm_exists('ldap_config')) {
function ldap_config($config, $key=false) {
    $details = $config->dump()['ldap'];
    if ($key && array_key_exists($key, $details)) {
        return $details[$key];
    }
    return $details;
}}
