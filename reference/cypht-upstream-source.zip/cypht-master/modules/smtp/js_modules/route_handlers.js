// TODO: This function is too large for a route handler, decouple it into multiple functions with action scope focused.
function applySmtpComposePageHandlers(routeParams) {
    init_resumable_upload()

    setupActionSchedule(function () {
        $('.smtp_send_placeholder').trigger('click');
    });

    const composeType = Number($('.compose_form').data('compose-type'));

    if (composeType === 1) {
        useKindEditor();
    }
    else if (composeType === 2) {
        useMarkdownEditor();
    }

    var interval = Hm_Utils.get_from_global('compose_save_interval', 30);
    Hm_Timer.add_job(function() { save_compose_state(); }, interval, true);
    $('.draft_title').on("click", function() { $('.draft_list').toggle(); });
    $('.toggle_recipients').on("click", function() { return toggle_recip_flds(); });
    $('.smtp_reset').on("click", reset_smtp_form);
    $('.delete_draft').on("click", function() { smtp_delete_draft($(this).data('id')); });
    $('.smtp_save').on("click", function() { save_compose_state(false, true); });
    $('.smtp_send_archive').on("click", function() { send_archive(false, true); });

    const modal = new Hm_Modal({
        modalId: 'emptySubjectBodyModal',
        title: 'Warning',
        btnSize: 'sm'
    });

    $('.smtp_send_placeholder').on("click", function (e) {
        if (window.kindEditor) {
            kindEditor.sync();
        }

        if (window.mdEditor) {
            mdEditor.codemirror.save();
        }

        const body = $('.compose_body').val().trim();
        const subject = $('.compose_subject').val().trim();

        let modalContentHeadline = '';
        let dontWanValueInStorage = '';
        let showBtnSendAnywayDontWarnFuture = true;

        // If the subject is empty, we should warn the user
        if (!subject) {
            dontWanValueInStorage = 'dont_warn_empty_subject';
            modalContentHeadline = "Your subject is empty!";
        }

        // If the body is empty, we should warn the user
        if (!body) {
            dontWanValueInStorage = 'dont_warn_empty_body';
            modalContentHeadline = "Your body is empty!";
        }

        // if both the subject and the body are empty, we should warn the user
        if (!body && !subject) {
            dontWanValueInStorage = 'dont_warn_empty_subject_body';
            modalContentHeadline = "Your subject and body are empty!";
        }

        if (hm_module_is_supported('contacts')) {
            var checkInList = check_cc_exist_in_contacts_list();
            // if contact_cc not exist in contact list for user
            if (checkInList) {
                modalContentHeadline = "Address mail not exist in your contact list";
                showBtnSendAnywayDontWarnFuture = false;
            }

            // Below we add emails to Trusted sender
            if (hm_enable_collect_address_on_send) {
                const parseEmails = (selector) => {
                    return $(selector).val().split(/[,;]+/).map(e => e.trim()).filter(Boolean);
                };

                if (true) {
                    const emailSet = new Set();
                    ['#compose_to', '#compose_cc', '#compose_bcc'].forEach(selector => {
                        parseEmails(selector).forEach(email => {
                            emailSet.add(email);
                        });
                    });
                    const listMails = [...emailSet].join(';');
                    add_email_in_contact_trusted(listMails);
                }
            }
        }

        // If the user has disabled the warning or has enabled it in general settings, we should send the message
        if (hm_enable_collect_address_on_send || Boolean(Hm_Utils.get_from_local_storage(dontWanValueInStorage))) {
            handleSendAnyway();
        }
        // Otherwise, we should show the modal if we have a headline
        else if (modalContentHeadline) {
            modalContentHeadline = `<p>${hm_trans(modalContentHeadline)}</p>`;
            return showModal(modalContentHeadline);
        }
        // Subject and body are not empty, we can send the message
        else {
            handleSendAnyway();
        }

        /*
        ========================================
        Functions declarations
        ========================================
        */
        function showModal() {
            if (! modal.modalContent.html()) {
                modal.addFooterBtn(hm_trans('Send anyway'), 'btn-warning', handleSendAnyway);
                if (showBtnSendAnywayDontWarnFuture) {
                    modal.addFooterBtn(hm_trans("Send anyway and don't warn in the future"), 'btn-warning', handleSendAnywayAndDontWarnMe);
                }
            }
            modal.setContent(modalContentHeadline + checkInList + `<p>${hm_trans('Are you sure you want to send this message?')}</p>`);
            modal.open();
        }

        function waitForValueChange(selector, targetValue) {
            return new Promise((resolve) => {
                const checkValue = () => {
                    if ($(selector).val() !== targetValue) {
                        resolve();  
                    } else {
                        setTimeout(checkValue, 100); 
                    }
                };
                checkValue();  
            });
        }

        async function handleSendAnyway() {
            if ($('.saving_draft').val() !== '0') {
                if ($('.nexter_input').val()) {
                    Hm_Notices.show([hm_trans('Please wait, message scheduling in progress...')]);
                } else {
                    Hm_Notices.show([hm_trans('Please wait, sending message...')]);
                }
                await waitForValueChange('.saving_draft', '0');
            }

            if (handleMissingAttachment()) {
                if ($('.nexter_input').val()) {
                    save_compose_state(false, true, $('.nexter_input').val(), function(res) {
                        if (res.draft_id) {
                            reset_smtp_form(false);
                            Hm_Notices.show([hm_trans('Operation successful')]);
                        }
                    });
                } else {
                    document.getElementsByClassName("smtp_send")[0].click();
                }
            } else {
                e.preventDefault();
            }
        }

        function handleSendAnywayAndDontWarnMe() {
            Hm_Utils.save_to_local_storage(dontWanValueInStorage, true);
            handleSendAnyway();
        };

        function handleMissingAttachment() {
            var uploaded_files = $("input[name='uploaded_files[]']").map(function () { return $(this).val(); }).get();
            const compose_body_value = document.getElementById('compose_body').value;
            const force_send = document.getElementById('force_send')?.value;
            var reminder_value = $('.compose_form').data('reminder');
            if (reminder_value === 1 && force_send !== '1') {
                let all_translated_keywords = [];
                for (let lang in window.hm_translations) {
                    if (window.hm_translations.hasOwnProperty(lang)) {
                        // Get translated keywords for the current language
                        const translated_keywords = hm_trans('attachment,file,attach,attached,attaching,enclosed,CV,cover letter', lang).split(',');
                        // Concatenate translated keywords with the array
                        all_translated_keywords = all_translated_keywords.concat(translated_keywords);
                    }
                }
                const additional_keywords = ['.doc', '.pdf'];
                // Split the translated keywords into an array && Add additional keywords or file extensions
                const combined_keywords = all_translated_keywords.concat(additional_keywords);
                // Build the regex pattern
                const pattern = new RegExp('(' + combined_keywords.map(keyword => keyword.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&')).join('|') + ')', 'i');
                // Check if the pattern is found in the message
                if (pattern.test(compose_body_value) && uploaded_files.length === 0) {

                    if (confirm(hm_trans('We couldn\'t find the attachment you referred to. Please confirm if you attached it or provide the details again.'))) {
                        force_send_message();
                    } else {
                        return false;
                    }
                }
            }
            return true;
        }
    });
    $('.compose_form').on('submit', function() {
        process_compose_form();
    });
    if ($('.compose_cc').val() || $('.compose_bcc').val()) {
        toggle_recip_flds();
    }
    // Handle focus management for different compose scenarios
    if (routeParams.reply == 1 || routeParams.reply_all == 1) {
        replace_cursor_positon ($('textarea[name="compose_body"]'));
    }
    else if (routeParams.forward == 1) {
        replace_cursor_positon ($('textarea[name="compose_body"]'));
        setTimeout(function() {
            save_compose_state();
        }, 100);
    }
    else {
        var toField = $('.compose_to');
        if (toField.val().trim() === '') {
            toField.focus();
        } else {
            $('textarea[name="compose_body"]').focus();
        }
    }

    const getSmtpProfileCallback = (res) => {
        const deliveryReceiptCheckBox = $('#compose_delivery_receipt');
        deliveryReceiptCheckBox.next('label').next('span.badge').remove();
        if (! res.dsn_supported) {
            deliveryReceiptCheckBox.prop('checked', false);
            deliveryReceiptCheckBox.prop('disabled', true);
            deliveryReceiptCheckBox.next('label').after('<span class="badge bg-warning text-dark ms-2">Not supported by the selected SMTP server</span>');
        } else {
            deliveryReceiptCheckBox.prop('disabled', false);
            deliveryReceiptCheckBox.prop('checked', true);
        }
    };

    if ($('.sys_messages').text() != 'Message Sent') {
        get_smtp_profile($('.compose_server').val(), getSmtpProfileCallback);
    }
    $('.compose_server').on('change', function() {
        get_smtp_profile($('.compose_server').val(), getSmtpProfileCallback);
    });
    if($('.compose_attach_button').attr('disabled') == 'disabled'){
        check_attachment_dir_access();
    };

    $('.compose_container').attr('ondrop', 'move_recipient_to_section(event)').attr('ondragover', 'allow_drop(event)');
    $('.compose_to, .compose_cc, .compose_bcc').on('keypress', function(e) {
        if(e.which == 13) {
            e.preventDefault();
            text_to_bubbles(this);
        }
    });
    $('.compose_to, .compose_cc, .compose_bcc').on('keydown', function(e) {
        // Handle backspace to select/delete bubbles
        if(e.which == 8 || e.keyCode == 8) {
            var $input = $(this);
            var $bubblesContainer = $input.prev('.bubbles');
            var $bubbles = $bubblesContainer.find('.bubble');
            var $selectedBubble = $bubblesContainer.find('.bubble.bubble_selected');

            if ($input.val() === '' && $bubbles.length > 0) {
                e.preventDefault();
                if ($selectedBubble.length > 0) {
                    $(".bubble_dropdown-content").remove();
                    remove_recipient_from_list($selectedBubble.data('id'));
                    $selectedBubble.remove();
                    schedule_mta_sts_status_check();
                } else {
                    $bubbles.last().addClass('bubble_selected');
                }
            } else if ($input.val() !== '') {
                $bubblesContainer.find('.bubble_selected').removeClass('bubble_selected');
            }
        } else if (e.which !== 13) {
            // On any other key (except Enter), deselect selected bubble
            var $input = $(this);
            var $bubblesContainer = $input.prev('.bubbles');
            $bubblesContainer.find('.bubble_selected').removeClass('bubble_selected');
        }
    });
    $('.compose_to, .compose_cc, .compose_bcc').on('blur', function(e) {
        e.preventDefault();
        text_to_bubbles(this);
        $(this).prev('.bubbles').find('.bubble_selected').removeClass('bubble_selected');
    });
    $('.compose_subject, .compose_body, .compose_server, .smtp_send_placeholder, .smtp_send_archive').on('focus', function(e) {
        $('.compose_to, .compose_cc, .compose_bcc').each(function() {
            bubbles_to_text(this);
        });
    });
    $('.compose_to, .compose_cc, .compose_bcc').on('focus', function(e) {
        text_to_bubbles(this);
        $(this).prev('.bubbles').find('.bubble_selected').removeClass('bubble_selected');
    });
    $('.compose_container').on('click', function() {
        $(this).find('input').focus();
    });
    $(document).on('click', '.bubble_close', function(e) {
        e.stopPropagation();
        $(".bubble_dropdown-content").remove();
        remove_recipient_from_list($(this).parent().data('id'));
        $(this).parent().remove();
        schedule_mta_sts_status_check();
    });

    init_mta_sts_status_check();

    var selectedOption = $('#compose_smtp_id option[selected]');
    var selectedEmail = selectedOption.data('email');
    var selectedVal = selectedOption.val();

    var recipientsInput = $('#compose_cc');
    var excludedEmail = null;

    const excludeEmail = function () {
        var newRecipients = recipientsInput.val().split(',').filter(function(email) {
            if (email.includes(selectedEmail)) {
                excludedEmail = email;
                return false;
            }
            return true;
        }).join(', ');
        recipientsInput.val(newRecipients);
        schedule_mta_sts_status_check();
    };

    if (recipientsInput.val().includes(selectedEmail)) {
        excludeEmail();
        $(document).on('change', '#compose_smtp_id', function() {
            if ($(this).val() !== selectedVal) {
                if (!recipientsInput.val().includes(selectedEmail)) {
                    recipientsInput.val(recipientsInput.val() + ', ' + excludedEmail);
                    schedule_mta_sts_status_check();
                }
            } else {
                excludeEmail();
            }
        });
    }

    if (window.pgpComposePageHandler) pgpComposePageHandler();
    if (window.profilesComposePageHandler) profilesComposePageHandler();
}
