'use strict';

var get_smtp_profile = function(profile_value, callback) {
    if (typeof profile_value === "undefined" || profile_value == "0" || profile_value == "") {
        Hm_Notices.show('Please create a profile for saving sent messages option', 'warning');
    }
    else {
        Hm_Ajax.request(
            [{'name': 'hm_ajax_hook', 'value': 'ajax_profiles_status'},
            {'name': 'profile_value', 'value': profile_value},
            {'name': 'compose_smtp_id', 'value': profile_value}],
            function(res) {
                callback(res);
            }
        );
    }
};

var check_attachment_dir_access = function() {
    Hm_Notices.show('Attachment storage unavailable, please contact your site administrator', 'warning');
};

var smtp_test_action = function(event) {
    event.preventDefault();
    var form = $(this).closest('.smtp_connect');
    Hm_Ajax.request(
        [{'name': 'hm_ajax_hook', 'value': 'ajax_smtp_debug'},
            {'name': 'smtp_server_id', 'value': $('.smtp_server_id', form).val()}],
        false,
        {'smtp_connect': 1}
    );
};

var smtp_delete_action = function(event) {
    if (!hm_delete_prompt()) {
        return false;
    }
    event.preventDefault();
    var form = $(this).closest('.smtp_connect');
    Hm_Ajax.request(
        form.serializeArray(),
        function(res) {
            if (res.deleted_server_id) {
                form.parent().fadeOutAndRemove()
                Hm_Utils.set_unsaved_changes(1);
                Hm_Folders.reload_folders(true);
                decrease_servers('smtp');
            }
        },
        {'smtp_delete': 1}
    );
};

var smtp_delete_draft = function(id) {
    Hm_Ajax.request(
        [{'name': 'hm_ajax_hook', 'value': 'ajax_smtp_delete_draft'},
        {'name': 'draft_id', 'value': id}],
        function(res) {
            if (res.draft_id != -1) {
                $('.draft_'+id).remove();
                $('.draft_list').toggle();
            }
        }
    );
};

var send_archive = function() {
    $('.compose_post_archive').val(1);
    document.getElementsByClassName("smtp_send_placeholder")[0].click();
}

var save_compose_state = function(no_files, notice, schedule, callback) {
    var no_icon = true;
    if (notice) {
        no_icon = false;
    }

    // Sync editor content to textarea before saving
    if (window.kindEditor) {
        kindEditor.sync();
    }
    var uploaded_files = $("input[name='uploaded_files[]']").map(function(){return $(this).val();}).get();
    var body = $('.compose_body').val();
    var subject = $('.compose_subject').val();
    var to = $('.compose_to').val();
    var smtp = $('.compose_server').val();
    var cc = $('.compose_cc').val();
    var bcc = $('.compose_bcc').val();
    var inreplyto = $('.compose_in_reply_to').val();
    var delivery_receipt = $('#compose_delivery_receipt').prop('checked');

    var draft_id = $('.compose_draft_id').val();
    if (globals.draft_state == body+subject+to+smtp+cc+bcc+uploaded_files) {
        return;
    }
    globals.draft_state = body+subject+to+smtp+cc+bcc+uploaded_files;

    if (!body && !subject && !to && !cc && !bcc) {
        return;
    }
    $('.saving_draft').val(1);
    Hm_Ajax.request([{'name': 'hm_ajax_hook', 'value': 'ajax_smtp_save_draft'},
        {'name': 'draft_body', 'value': body},
        {'name': 'draft_id', 'value': draft_id},
        {'name': 'draft_smtp', 'value': smtp},
        {'name': 'draft_subject', 'value': subject},
        {'name': 'draft_cc', 'value': cc},
        {'name': 'draft_bcc', 'value': bcc},
        {'name': 'draft_notice', 'value': notice},
        {'name': 'draft_in_reply_to', 'value': inreplyto},
        {'name': 'delete_uploaded_files', 'value': no_files},
        {'name': 'draft_to', 'value': to},
        {'name': 'uploaded_files', 'value': JSON.stringify(uploaded_files)},
        {'name': 'schedule', 'value': schedule ?? ''},
        {'name': 'compose_delivery_receipt', 'value': delivery_receipt ?? ''}],
        function(res) {
            $('.saving_draft').val(0);
            if (res.draft_id) {
                $('.compose_draft_id').val(res.draft_id);
            }
            if (res.draft_subject) {
                $('.draft_list .draft_'+draft_id+' a').text(res.draft_subject);
            }

            if (callback) {
                callback(res);
            }
        },
        [],
        no_icon,
        false,
        function () {
            $('.saving_draft').val(0);
        }
    );
};

var toggle_recip_flds = function() {
    var symbol = '<i class="bi bi-plus-square-fill fs-3"></i>';
    if ($('.toggle_recipients').html() == '<i class="bi bi-plus-square-fill fs-3"></i>') {
        symbol = '<i class="bi bi-dash-square fs-3"></i>';
    }
    $('.toggle_recipients').html(symbol);
    $('.recipient_fields').toggle();
    return false;
}

var mta_sts_status_timer = false;
var mta_sts_last_recipient_state = false;
var mta_sts_status_request_id = 0;

var mta_sts_status_check_enabled = function() {
    return $('.mta-sts-status-container[data-mta-sts-enabled="1"]').length > 0;
};

var place_mta_sts_status_container = function() {
    var container = $('.mta-sts-status-container[data-mta-sts-enabled="1"]').first();
    if (container.length && $('.recipient_fields').length) {
        container.insertAfter($('.recipient_fields'));
    }
};

var compose_recipient_value = function(selector) {
    var values = [];
    var input = $(selector);
    input.prev('.bubbles').children('.bubble').each(function() {
        var value = $(this).attr('data-value');
        if (value) {
            values.push(value);
        }
    });
    if (input.val()) {
        values.push(input.val());
    }
    return values.join(', ');
};

var compose_recipient_state = function() {
    return {
        to: compose_recipient_value('.compose_to'),
        cc: compose_recipient_value('.compose_cc'),
        bcc: compose_recipient_value('.compose_bcc')
    };
};

var hide_mta_sts_status_container = function() {
    var container = $('.mta-sts-status-container[data-mta-sts-enabled="1"]').first();
    container.html('').addClass('d-none');
    place_mta_sts_status_container();
};

var update_mta_sts_status_container = function(html) {
    var container = $('.mta-sts-status-container[data-mta-sts-enabled="1"]').first();
    if (!container.length) {
        return;
    }
    if (!html) {
        hide_mta_sts_status_container();
        return;
    }
    container.replaceWith(html);
    place_mta_sts_status_container();
};

var refresh_mta_sts_status = function() {
    if (!mta_sts_status_check_enabled()) {
        return;
    }
    var recipients = compose_recipient_state();
    var recipient_state = recipients.to + '|' + recipients.cc + '|' + recipients.bcc;
    if (recipient_state == mta_sts_last_recipient_state) {
        return;
    }
    mta_sts_last_recipient_state = recipient_state;
    mta_sts_status_request_id++;
    if (!recipients.to && !recipients.cc && !recipients.bcc) {
        hide_mta_sts_status_container();
        return;
    }
    var request_id = mta_sts_status_request_id;
    Hm_Ajax.request([
        {'name': 'hm_ajax_hook', 'value': 'ajax_mta_sts_status'},
        {'name': 'compose_to', 'value': recipients.to},
        {'name': 'compose_cc', 'value': recipients.cc},
        {'name': 'compose_bcc', 'value': recipients.bcc}
    ], function(res) {
        if (request_id != mta_sts_status_request_id) {
            return;
        }
        update_mta_sts_status_container((res && res.mta_sts_status_display) ? res.mta_sts_status_display : '');
    }, [], true);
};

var schedule_mta_sts_status_check = function() {
    if (!mta_sts_status_check_enabled()) {
        return;
    }
    clearTimeout(mta_sts_status_timer);
    mta_sts_status_timer = setTimeout(refresh_mta_sts_status, 500);
};

var init_mta_sts_status_check = function() {
    if (!mta_sts_status_check_enabled()) {
        return;
    }
    place_mta_sts_status_container();
    $('.compose_to, .compose_cc, .compose_bcc').on('input change', schedule_mta_sts_status_check);
    schedule_mta_sts_status_check();
};

function smtpServersPageHandler() {
    $('.test_smtp_connect').on('click', smtp_test_action);
    $('.delete_smtp_connection').on('click', smtp_delete_action);
    var dsp = Hm_Utils.get_from_local_storage('.smtp_section');
    if (dsp === 'block' || dsp === 'none') {
        $('.smtp_section').css('display', dsp);
    }
}

var reset_smtp_form = function(save = true) {
    $('.compose_body').val('');
    $('.compose_subject').val('');
    $('.compose_to').val('');
    $('.compose_cc').val('');
    $('.compose_bcc').val('');
    $('.ke-content', $('iframe').contents()).html('');
    if (window.mdEditor && window.mdEditor.codemirror) {
        window.mdEditor.codemirror.getDoc().setValue('');
        window.mdEditor.codemirror.save();
    }
    $('.uploaded_files').html('');
    $('#compose_delivery_receipt').prop('checked', false);
    schedule_mta_sts_status_check();
    if (save) {
        save_compose_state(true);
    }
};

var replace_cursor_positon = function (txtElement) {
    txtElement.val('\r\n\r\n\r\n'+txtElement.val());
    txtElement.prop('selectionEnd',0);
    txtElement.focus();
}

var init_resumable_upload = function () {
    var r = new Resumable({
        target:'?page=compose&hm_ajax_hook=ajax_upload_chunk&draft_smtp=' + $(".compose_server").val(),
        testTarget:'?page=compose&hm_ajax_hook=ajax_get_test_chunk&draft_smtp=' + $(".compose_server").val(),
        testMethod: 'POST',
        headers: {
            'X-Requested-with': 'xmlhttprequest'
        }
    });
    r.assignBrowse(document.getElementsByClassName('compose_attach_button'));
    r.on('fileAdded', function(file, event){
        $('.uploaded_files').append('<tr id="tr-'+file.uniqueIdentifier+'"><td>'
                +file.fileName+'</td><td>'+file.file.type+' ' + (Math.round((file.file.size/1024) * 100)/100) + 'KB '
                +'</td><td><a class="remove_attachment text-danger" id="remove-'+file.uniqueIdentifier+'" style="display:none" href="#">Remove</a><a  id="pause-'+file.uniqueIdentifier+'" class="pause_upload" href="#">Pause</a><a style="display:none" id="resume-'+file.uniqueIdentifier+'" class="resume_upload" href="#">Resume</a></td></tr><tr><td colspan="2">'
                +'<div class="meter" style="width:100%"><span id="progress-'
                +file.uniqueIdentifier+'" style="width:0%;"><span class="progress" id="progress-bar-'
                +file.uniqueIdentifier+'"></span></span></div></td></tr>');
        r.upload()
        $('.pause_upload').on('click', function (e) {
            e.preventDefault();
            r.pause();
        });
        $('.resume_upload').on('click', function(e) {
            e.preventDefault();
            $('.remove_attachment').css('display', 'none');
            $('.pause_upload').css('display', '');
            $('.resume_upload').css('display', 'none');
            r.upload();
        });
        $('.remove_attachment').on('click', function(e) {
            e.preventDefault();
            var fileUniqueId = $(this).attr('id').replace('remove-', '');
            file = r.getFromUniqueIdentifier(fileUniqueId);
            if (file) {
                r.removeFile(file);
            }
            $(this).parent().parent().next('tr').remove();
            $(this).parent().parent().remove();
        });
    });
    r.on('fileProgress', function(file) {
        var progress = Math.floor(file.progress() * 100);
        $('#progress-' + file.uniqueIdentifier).css('width', progress+'%');
    });
    r.on('fileSuccess', function(file) {
        $('.remove_attachment').css('display', '');
        $('.pause_upload').css('display', 'none');
        $('.resume_upload').css('display', 'none');
        $('#tr-'+file.uniqueIdentifier).append('<td style="display:none"><input name="uploaded_files[]" type="text" value="'+file.fileName+'" /></td>');
        $('#progress-bar-' + file.uniqueIdentifier).css('background-color', 'green');
        $('#progress-' + file.uniqueIdentifier).parent().css('opacity', '0');
    });
    r.on('fileError', function(file, message) {
        $('#progress-bar-' + file.uniqueIdentifier).css('background-color', 'red');
    });
    r.on('pause', function() {
        $('.remove_attachment').css('display', 'none');
        $('.pause_upload').css('display', 'none');
        $('.resume_upload').css('display', '');
    });
    $('.remove_attachment').on('click', function(e) {
        e.preventDefault();
        var fileUniqueId = $(this).attr('id').replace('remove-', '');
        $(this).parent().parent().next('tr').remove();
        $(this).parent().parent().remove();
        file = r.getFromUniqueIdentifier(fileUniqueId);
        r.removeFile(file);
    });
}

var move_recipient_to_section = function(e) {
    e.preventDefault();
    var id = e.dataTransfer.getData("text");
    var target = $(e.target);
    if (!target.hasClass('compose_container')) {
        target = target.closest('.compose_container');
    }
    target.find('.bubbles').append($('#'+id));
    var input = target.find('input');
    input.focus();
    schedule_mta_sts_status_check();
};

var allow_drop = function(e) {
    e.preventDefault();
};

var drag = function(e) {
    e.dataTransfer.setData('text', e.target.id);
};

var bubbles_to_text = function(input) {
    var value = '';
    $(input).prev().children().each(function() {
        if (value) {
            value = value + ', ';
        }
        value = value + $(this).attr('data-value');
        $(this).remove();
    });
    if (value) {
        if ($(input).val()) {
            value = value + ', ' + $(input).val();
        }
        $(input).val(value);
    }
    $(input).css('width', '95%');
    schedule_mta_sts_status_check();
};

var text_to_bubbles = function(input) {
    var contact_id = input.getAttribute("data-id");
    var contact_type = input.getAttribute("data-type");
    var contact_source = input.getAttribute("data-source");

    if ($(input).val()) {
        var recipients = $(input).val().split(/,|;/);
        var invalid_recipients = '';

        for (var i = 0; i < recipients.length; i++) {
            if (is_valid_recipient(recipients[i])) {
                append_bubble(recipients[i].trim(), input, contact_id, contact_type, contact_source);
            } else {
                if (invalid_recipients) {
                    invalid_recipients = invalid_recipients + ', ';
                }
                invalid_recipients = invalid_recipients + recipients[i];
            }
        }
        $(input).val(invalid_recipients);
        schedule_mta_sts_status_check();
    }
};

var bubble_index = 0;
var append_bubble = function(value, to, id, type, source) {
    var bubble = document.createElement('div');
    bubble.id = 'bubble_' + bubble_index;
    bubble.className = 'bubble bubble_dropdown-toggle';
    bubble.draggable = true;
    bubble.onclick = function() { toggle_bubble_dropdown(this); };
    bubble.ondragstart = drag;
    if (id !== null) {
        bubble.dataset.id = id;
    }
    if (type !== null) {
        bubble.dataset.type = type;
    }
    if (source !== null) {
        bubble.dataset.source = source;
    }
    bubble.dataset.value = value;
    bubble.textContent = value;

    var close = document.createElement('span');
    close.className = 'bubble_close';
    close.textContent = '\u00d7';
    bubble.appendChild(close);

    $(to).prev().append(bubble);
    bubble_index++;
};

var toggle_bubble_dropdown = function (element) {
    var dropdownContent = element.nextElementSibling;

    if (!dropdownContent) {
        var textValue = element.dataset.value;
        var contact_id = element.getAttribute('data-id');
        var contact_type = element.getAttribute('data-type');
        var contact_source = element.getAttribute('data-source');
        dropdownContent = document.createElement('div');
        dropdownContent.classList.add('bubble_dropdown-content');

        var list = document.createElement('ul');
        var copyItem = document.createElement('li');
        var copy = document.createElement('span');
        copy.dataset.value = textValue;
        copy.onclick = function() { copy_text_to_clipboard(this); };
        var copyIcon = document.createElement('i');
        copyIcon.className = 'bi bi-copy';
        copy.append(copyIcon, ' Copy');
        copyItem.appendChild(copy);
        list.appendChild(copyItem);

        if (contact_id !== null && contact_id !== 'null') {
            var editItem = document.createElement('li');
            var edit = document.createElement('a');
            edit.href = '?page=contacts&contact_id=' + encodeURIComponent(contact_id) +
                '&contact_source=' + encodeURIComponent(contact_source || '') +
                '&contact_type=' + encodeURIComponent(contact_type || '');
            var editIcon = document.createElement('i');
            editIcon.className = 'bi bi-pencil-fill';
            edit.append(editIcon, ' Edit');
            editItem.appendChild(edit);
            list.appendChild(editItem);
        }

        dropdownContent.appendChild(list);
        element.parentNode.appendChild(dropdownContent);
    }

    dropdownContent.classList.toggle('show');
}

var copy_text_to_clipboard = function(e) {
    navigator.clipboard.writeText(e.dataset.value);
    $(".bubble_dropdown-content").remove();
}

var is_valid_recipient = function(recipient) {
    // This function extracts an email address from RFC 5322 formatted recipient strings
    // and validates it using Hm_Utils.is_valid_email()
    if (!recipient) {
        return false;
    }
    var val = recipient.trim();

    if (!val) {
        return false;
    }

    // Step 1: Remove comments in parentheses (RFC 5322 allows comments)
    // Examples: "Name (comment) <email>", "email@domain.com (comment)"
    // Handle nested parentheses properly
    var depth = 0;
    var cleaned = '';
    for (var i = 0; i < val.length; i++) {
        if (val[i] === '(') {
            depth++;
        } else if (val[i] === ')') {
            depth--;
        } else if (depth === 0) {
            cleaned += val[i];
        }
    }
    // Collapse multiple whitespaces and trim
    val = cleaned.replace(/\s+/g, ' ').trim();

    if (!val) {
        return false;
    }

    // Step 2: Handle RFC 5322 group syntax: "display-name : mailbox-list ;"
    // After splitting by comma/semicolon, we might get "Group Name: email@domain.com"
    // BUT: Ignore colons inside square brackets (IPv6 addresses like user@[IPv6:2001:db8::1])
    if (val.includes(':') && !val.includes('<')) {
        var colonIndex = val.indexOf(':');
        var bracketIndex = val.indexOf('[');

        // Only treat as group syntax if colon appears before any brackets
        // or if there are no brackets at all
        if (bracketIndex === -1 || colonIndex < bracketIndex) {
            var afterColon = val.substring(colonIndex + 1).trim();
            if (afterColon) {
                val = afterColon;
            } else {
                // Empty group like "Undisclosed recipients:;" - no email to extract
                return false;
            }
        }
    }

    // Step 3: Extract email from angle brackets or plain text
    var email = '';
    var angleBracketMatch = val.match(/<([^>]+)>/);

    if (angleBracketMatch) {
        // Format: "Display Name <email@example.com>"
        email = angleBracketMatch[1].trim();
    } else {
        // No angle brackets - extract email from plain text
        // Remove quoted display name if present: "Display Name" email@example.com
        val = val.replace(/^"[^"]*"\s+/, '');

        // Find the word containing @ (typically the last word)
        var parts = val.split(/\s+/);
        for (var i = parts.length - 1; i >= 0; i--) {
            if (parts[i].includes('@')) {
                email = parts[i];
                break;
            }
        }
    }

    if (!email) {
        return false;
    }

    // Step 4: Clean up extracted email (remove trailing punctuation from splitting)
    // Preserve quoted local-part (e.g., "user name"@example.com)
    if (email.includes('@')) {
        var atPos = email.indexOf('@');
        var localPart = email.substring(0, atPos);
        var domainPart = email.substring(atPos);

        // Clean domain part (remove trailing commas, semicolons, etc.)
        domainPart = domainPart.replace(/[,;]+$/g, '').trim();

        // Clean local part only if quotes aren't wrapping it completely
        if (!(localPart.startsWith('"') && localPart.endsWith('"'))) {
            localPart = localPart.replace(/^["',;]+|["',;]+$/g, '').trim();
        }

        email = localPart + domainPart;
    } else {
        email = email.replace(/^["',;]+|["',;]+$/g, '').trim();
    }

    // Step 5: Validate the extracted email using the core validation function
    // All RFC 5322 validation rules are handled by is_valid_email
    return Hm_Utils.is_valid_email(email);
};

var process_compose_form = function(){
    var msg_uid = getMessageUidParam();
    if (getListPathParam()) {
        var detail = Hm_Utils.parse_folder_path(getListPathParam(), 'imap');
        var class_name = 'imap_' + detail.server_id + '_' + msg_uid + '_' + detail.folder;
        var key = 'imap_' + Hm_Utils.get_url_page_number() + '_' + getListPathParam();
        Hm_Message_List.prev_next_links(key, class_name, function(links) {
            const next_message = links[1];
            if (next_message) {
                $('.compose_next_email_data').val(next_message);
            }
        });
    }

    var uploaded_files = $("input[name='uploaded_files[]']").map(function () { return $(this).val(); }).get();
    $('#send_uploaded_files').val(JSON.stringify(uploaded_files));
    Hm_Ajax.show_loading_icon();
    $('.smtp_send_placeholder').addClass('disabled_input');
    $('.smtp_send_archive').addClass('disabled_input');
    $('.smtp_send').on("click", function () { return false; });
}

var force_send_message = function() {
    // Check if the force_send input already exists
    var forceSendInput = document.getElementById('force_send');
    if (! forceSendInput) {
        // Create a hidden input element
        var hiddenInput = document.createElement('input');
        hiddenInput.type = 'hidden';
        hiddenInput.name = 'force_send';
        hiddenInput.value = '1';
        hiddenInput.id = 'force_send';
        hiddenInput.classList.add('force_send');
        // Append the hidden input to the form
        var form = document.querySelector('.compose_form');
        form.appendChild(hiddenInput);
    }
}

function smtpSettingsPageHandler() {
    $('#clear_chunks_button').on('click', function(e) {
        e.preventDefault();
        Hm_Ajax.request(
            [{'name': 'hm_ajax_hook', 'value': 'ajax_clear_attachment_chunks'}],
            function(res) {

            },
            []
        );
    });
}

$(function() {
    if (hm_is_logged() && window.inAppContext && hm_module_is_supported('scheduled_sends')) {
        let scheduled_msg_count = 0;
        let sendScheduledMessages = function() { 
            Hm_Ajax.request(
                [{'name': 'hm_ajax_hook', 'value': 'ajax_send_scheduled_messages'}],
                function(res) {
                    scheduled_msg_count = res.scheduled_msg_count;
                },
            );
        }

        sendScheduledMessages();
        setInterval(sendScheduledMessages, 60000);
        window.onbeforeunload = (e) => {
            if (scheduled_msg_count > 0 && e.currentTarget.location.hostname !== document.location.hostname) {
                return sprintf(hm_trans("You have %d scheduled messages that won\'t be executed if you quit"), scheduled_msg_count);
            }
        };
    }
});
