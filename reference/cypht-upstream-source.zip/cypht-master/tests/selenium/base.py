#!/usr/bin/python

# To run these tests you must copy one of the example files to "creds.py" in
# this directory, and edit it for your environment. There are 2 example files
# in this directory:
#
# remote_creds.example.py:  Configure the Selenium tests to run with BrowserStack
# local_creds.example.py:   Configure the Selenium tests to run locally

import re
from creds import SITE_URL, USER, PASS, get_driver
from selenium.webdriver.common.by import By
from selenium.common import exceptions
from contextlib import contextmanager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as exp_cond
import glob
import subprocess
import json
import time
import os

class WebTest:

    driver = None
    _pre_click_nav_count = None

    def __init__(self, cap=None):
        self.read_ini()
        self.driver = get_driver(cap)
        self.browser = False
        if 'browserName' in self.driver.capabilities:
            self.browser = self.driver.capabilities['browserName'].lower()

        # Ensure a consistent, generous viewport in CI to avoid responsive layout issues
        try:
            if os.getenv("GITHUB_ACTIONS") == "true":
                self.driver.set_window_rect(x=0, y=0, width=1920, height=1080)
                actual_size = self.driver.get_window_size()
                if actual_size['width'] < 1000:  # If still too small, try alternative method
                    self.driver.execute_script("window.resizeTo(1920, 1080);")
            else:
                current_size = self.driver.get_window_size()
                self.driver.set_window_size(current_size['width'], 5000)
        except Exception as e:
            print(f" - Warning: Could not set window size: {e}")

        self.load()

    def read_ini(self):
        self.modules = []
        self.servers = 1
        self.auth_type = ''
        result = subprocess.run(['php', 'get_config.php'], stdout=subprocess.PIPE)
        config_dict = json.loads(result.stdout.decode())
        if 'modules' in config_dict and isinstance(config_dict['modules'], list):
            self.modules += config_dict['modules']
        if 'auth_type' in config_dict:
            self.auth_type = config_dict['auth_type']

    def load(self):
        print(" - loading site")
        self.go(SITE_URL)
        # In headless mode, maximize_window() doesn't work and can cause issues
        # Set window size explicitly instead
        try:
            if os.getenv("GITHUB_ACTIONS") == "true":
                self.driver.set_window_rect(x=0, y=0, width=1920, height=1080)
                self.driver.execute_script("window.resizeTo(1920, 1080);")
            else:
                self.driver.maximize_window()
        except Exception:
            print(" - Could not set window size :(")
        if self.browser == 'safari':
            try:
                self.driver.set_window_size(1920,1080)
            except Exception:
                print(" - Could not maximize Safari")

    def save_debug_artifacts(self, name):
        if os.getenv("GITHUB_ACTIONS") != "true":
            return
        os.makedirs(f"artifacts/{name}", exist_ok=True)
        with open(f"artifacts/{name}/page_dump.html", "w", encoding="utf-8") as f:
            f.write(self.driver.page_source)
        self.driver.save_screenshot(f"artifacts/{name}/page_screenshot.png")
        logs = self.driver.get_log("browser")
        with open(f"artifacts/{name}/console_logs.json", "w", encoding="utf-8") as f:
            json.dump(logs, f, indent=2)

    def mod_active(self, name):
        # debug self.modules
        echo = " - modules enabled: "
        for mod in self.modules:
            echo += mod + " "
        print(echo)
        if name in self.modules:
            return True
        print(" - module not enabled: %s" % name)
        return False

    def single_server(self):
        if self.servers <= 1:
            return True
        print(" - servers account: %s" % self.servers)
        return False

    def go(self, url):
        self.driver.get(url)
        self.wait_for_page_ready()

    def login(self, user, password):
        print(" - logging in")
        user_el = self.by_name('username')
        pass_el = self.by_name('password')
        user_el.send_keys(user)
        pass_el.send_keys(password)
        self.by_css('input[value=Login]').click()

    def change_val(self, el, val):
        self.driver.execute_script('''
            var e=arguments[0]; var v=arguments[1]; e.value=v;''',
            el, val)

    def confirm_alert(self):
        WebDriverWait(self.driver, 3).until(exp_cond.alert_is_present(), 'timed out')
        alert = self.driver.switch_to.alert
        alert.accept()

    def logout_no_save(self):
        print(" - logging out")
        self.driver.find_element(By.CLASS_NAME, 'logout_link').click()
        logout = self.by_id('logout_without_saving').click()

    def logout(self):
        print(" - logging out")
        self.driver.find_element(By.CLASS_NAME, 'logout_link').click()

    def save_and_logout(self):
        print(" - saving and logging out")
        # Navigate directly to the save page (avoids SPA/modal complexity)
        self.go(SITE_URL + '?page=save')
        self.wait(By.ID, 'password', timeout=15)
        self.driver.find_element(By.ID, 'password').send_keys(PASS)
        btn = WebDriverWait(self.driver, 10).until(
            exp_cond.element_to_be_clickable(
                (By.NAME, 'save_settings_permanently_then_logout')
            )
        )
        self.driver.execute_script("arguments[0].click();", btn)
        # Wait for PHP to save and redirect to login
        try:
            WebDriverWait(self.driver, 30).until(exp_cond.staleness_of(btn))
        except Exception:
            pass
        self.wait(By.NAME, 'username', timeout=30)

    def end(self):
        self.driver.quit()

    def by_id(self, el_id):
        print(" - finding element by id {0}".format(el_id))
        return self.driver.find_element(By.ID, el_id)

    def by_tag(self, name):
        print(" - finding element by tag name {0}".format(name))
        return self.driver.find_element(By.TAG_NAME, name)

    def by_name(self, name):
        print(" - finding element by name {0}".format(name))
        return self.driver.find_element(By.NAME, name)

    def by_css(self, selector):
        print(" - finding element by selector {0}".format(selector))
        return self.driver.find_element(By.CSS_SELECTOR, selector)

    def by_class(self, class_name):
        print(" - finding element by class {0}".format(class_name))
        return self.driver.find_element(By.CLASS_NAME, class_name)

    def visible_by_class(self, class_name):
        print(" - finding visible element by class {0}".format(class_name))
        elements = self.driver.find_elements(By.CLASS_NAME, class_name)
        for element in elements:
            try:
                if element.is_displayed():
                    return element
            except exceptions.StaleElementReferenceException:
                continue
        raise exceptions.NoSuchElementException(
            f"No visible element found with class name '{class_name}'"
        )

    def wait_for_class_text_contains(self, class_name, expected_text, timeout=60):
        print(f" - waiting for class {class_name} to contain '{expected_text}'")
        def _condition(driver):
            elements = driver.find_elements(By.CLASS_NAME, class_name)
            for element in elements:
                try:
                    if element.is_displayed():
                        text = element.text.strip()
                        if expected_text in text:
                            return element
                except exceptions.StaleElementReferenceException:
                    continue
            return False
        return WebDriverWait(self.driver, timeout).until(_condition)

    def wait_for_element_by_class(self, class_name, timeout=60):
        """Wait for an element to be present and visible by class name"""
        print(" - waiting for element by class {0}".format(class_name))
        WebDriverWait(self.driver, timeout).until(
            exp_cond.presence_of_element_located((By.CLASS_NAME, class_name))
        )
        element = self.driver.find_element(By.CLASS_NAME, class_name)
        WebDriverWait(self.driver, timeout).until(
            exp_cond.visibility_of(element)
        )
        return element

    def by_xpath(self, element_xpath):
        print(" - finding element by xpath {0}".format(element_xpath))
        return self.driver.find_element(By.XPATH, element_xpath)

    def element_exists(self, class_name):
        print(" - checking if element exists by class {0}".format(class_name))
        try:
            self.by_class(class_name)
            return True
        except Exception:
            return False

    def wait(self, el_type=By.TAG_NAME, el_value="body", timeout=60):
        print(" - waiting for page by {0}: {1} ...".format(el_type, el_value))
        element = WebDriverWait(self.driver, timeout).until(
            exp_cond.presence_of_element_located((el_type, el_value)))

    def wait_on_class(self, class_name, timeout=60):
        self.wait(By.CLASS_NAME, class_name)

    def wait_with_folder_list(self):
        self.wait(By.CLASS_NAME, "main")

    def wait_on_sys_message(self, timeout=60):
        wait = WebDriverWait(self.driver, timeout)
        element = wait.until(wait_for_non_empty_text((By.CLASS_NAME, "sys_messages"))
)

    def wait_for_navigation_to_complete(self, timeout=60):
        print(" - waiting for the navigation to complete...")
        # Wait for the SPA navigation to finish. The counter is captured before
        # the triggering click and checked here so we wait for the specific
        # navigation we initiated, not a previous one.
        expected = (self._pre_click_nav_count or 0) + 1
        self._pre_click_nav_count = None
        try:
            WebDriverWait(self.driver, timeout).until(
                lambda d: (d.execute_script("return window.cyphtNavDone || 0;") or 0) >= expected
            )
        except Exception:
            print(" - navigation completion check timed out, continuing...")
            pass
        # Wait for any background requests to finish. Some pages fetch their
        # content asynchronously after the page shell has loaded.
        try:
            WebDriverWait(self.driver, timeout).until(
                lambda d: d.execute_script(
                    "return (typeof Hm_Ajax !== 'undefined') ? Hm_Ajax.active_reqs === 0 : true;"
                )
            )
        except Exception:
            print(" - AJAX idle check timed out, continuing...")
            pass

    def wait_for_page_ready(self, timeout=60):
        """Wait for document readiness and idle network to reduce flakiness after navigation."""
        try:
            # Wait for DOM ready
            WebDriverWait(self.driver, timeout).until(
                lambda d: d.execute_script("return document.readyState") == "complete"
            )
        except Exception:
            print(" - document.readyState wait failed, continuing...")
        # Best-effort small delay to allow post-load JS to attach handlers in CI
        try:
            WebDriverWait(self.driver, 5).until(
                lambda d: d.execute_script(
                    "return !!(window.requestIdleCallback || window.setTimeout)"
                )
            )
        except Exception:
            pass

    def wait_for_settings_to_expand(self):
        print(" - waiting for the settings section to expand...")
        try:
            # First try to find the settings button and click it
            settings_button = self.by_css('[data-bs-target=".settings"]')
            if settings_button.is_displayed():
                # Check if settings are already expanded
                try:
                    settings_div = self.by_class('settings')
                    if settings_div.is_displayed():
                        print(" - settings already expanded")
                        return
                except:
                    pass

                # Click to expand
                settings_button.click()

                # Wait for the settings to be displayed
                try:
                    WebDriverWait(self.driver, 60).until(lambda x: self.by_class('settings').is_displayed())
                    print(" - settings expanded successfully")
                except:
                    print(" - settings expansion timeout, continuing anyway")
            else:
                print(" - settings button not visible, skipping expansion")
        except Exception as e:
            print(f" - settings expansion failed: {e}")
            # Continue anyway, the settings might already be expanded

    def click_when_clickable(self, el):
        print(" - waiting for element to be clickable")
        self._capture_nav_count()
        try:
            # Scroll element into view
            self.driver.execute_script("arguments[0].scrollIntoView({block: 'center', behavior: 'instant'});", el)

            # Wait for element to be clickable
            WebDriverWait(self.driver, 60).until(
                exp_cond.element_to_be_clickable(el)
            )

            # Try regular click first
            try:
                el.click()
                return
            except Exception as click_error:
                print(f" - regular click failed: {click_error}")
                print(" - trying JavaScript click as fallback")
                # Use JavaScript click as fallback
                self.driver.execute_script("arguments[0].click();", el)

        except Exception as e:
            print(f" - click_when_clickable failed: {e}")
            # Final fallback: try JavaScript click without waiting
            try:
                self.driver.execute_script("arguments[0].click();", el)
            except Exception as js_error:
                print(f" - JavaScript click also failed: {js_error}")
                raise e

    def _capture_nav_count(self):
        """Capture the current navigation done-count before a click."""
        try:
            self._pre_click_nav_count = self.driver.execute_script("return window.cyphtNavDone || 0;")
        except Exception:
            self._pre_click_nav_count = None

    def safe_click(self, element):
        """Safely click an element with retry logic"""
        print(" - safely clicking element")
        self._capture_nav_count()
        max_attempts = 3
        for attempt in range(max_attempts):
            try:
                # Scroll element into view
                self.driver.execute_script("arguments[0].scrollIntoView({block: 'center', behavior: 'instant'});", element)
                WebDriverWait(self.driver, 60).until(exp_cond.element_to_be_clickable(element))
                element.click()
                return
            except Exception as e:
                if attempt == max_attempts - 1:
                    raise e
                print(f" - click attempt {attempt + 1} failed, retrying...")
                time.sleep(1)

    def safari_workaround(self, timeout=1):
        if self.browser == 'safari':
            print(" - waiting {0} extra second for Safari".format(timeout))
            self.driver.implicitly_wait(timeout)

class wait_for_non_empty_text(object):
    def __init__(self, locator):
        self.locator = locator

    def __call__(self, driver):
        try:
            element_text = driver.find_element(*self.locator).text.strip()
            print(element_text)
            return element_text != ""
        except (exceptions.StaleElementReferenceException,
                exceptions.NoSuchElementException):
            return False
